using UnityEngine;

public class RotationCopier : MonoBehaviour
{
    public Transform original;

    private void Update()
    {
        transform.rotation = original.rotation;
    }
}
