using System.IO;
using UnityEngine;

namespace BeetleMania
{
    public class SceneManager : MonoBehaviour
    {
        private void OnApplicationQuit()
        {
            var info = new DirectoryInfo(Application.persistentDataPath + "/Captures");
            var fileInfo = info.GetFiles();

            foreach (var file in fileInfo)
            {
                file.Delete();
            }
        }
    }
}
