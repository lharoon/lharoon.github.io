using UnityEngine;

public class TournamentSelectionScreenManager : MonoBehaviour
{
    public Animator exitTransition;

    public void LoadTournamentScreen()
    {
        exitTransition.gameObject.SetActive(true);
        StartCoroutine(SceneLoader.LoadSceneAfterT(GameInfo.tournamentScreenName,
            exitTransition.GetCurrentAnimatorStateInfo(0).length));
    }
}
