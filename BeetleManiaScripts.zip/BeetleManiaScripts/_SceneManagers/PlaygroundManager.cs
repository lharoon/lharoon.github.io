using GameUtils;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

namespace BeetleMania
{
    public class PlaygroundManager : SceneManager
    {
        public Toggle soundToggle, bgmToggle; // TEMP

        [SerializeField]
        private AudioMixer audioMixer;

        private void Start()
        {
            Time.timeScale = 1; // TEMP

            GameInfo.playSfx = true;
            GameInfo.playBgm = false;

            soundToggle.isOn = GameInfo.playSfx;
            bgmToggle.isOn = GameInfo.playBgm;
        }

        private void Update()
        {
            // TEMP
            if (audioMixer != null)
            {
                audioMixer.SetFloat("sfxVolume", !GameInfo.playSfx ? -80f : 0f);
                audioMixer.SetFloat("bgmVolume", !GameInfo.playBgm ? -80f : 0f);
            }
        }

        public void RestartScene()
        {
            GameInfo.lastActiveArenaIdx = FindObjectOfType<ArenasManager>().ActiveArenaIdx;
            LoadPlayground();
        }

        public void LoadPlayground()
        {
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.playgroundName));
        }

        public void LoadTitleScreen()
        {
            GameInfo.lastActiveArenaIdx = FindObjectOfType<ArenasManager>().ActiveArenaIdx;
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.titleScreenName));
        }
    }
}
