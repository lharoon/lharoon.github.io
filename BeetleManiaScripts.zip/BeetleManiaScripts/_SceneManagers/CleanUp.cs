using System.IO;
using UnityEngine;

public class CleanUp : MonoBehaviour // TODO: Delete
{
    private void OnApplicationQuit()
    {
        var info = new DirectoryInfo(Application.persistentDataPath + "/Captures");
        var fileInfo = info.GetFiles();

        foreach (var file in fileInfo)
        {
            file.Delete();
        }
    }
}
