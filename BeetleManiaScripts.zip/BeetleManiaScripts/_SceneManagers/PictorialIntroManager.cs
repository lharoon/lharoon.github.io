using UnityEngine;

public class PictorialIntroManager : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetKeyDown(GameInfo.advanceKey))
            SceneLoader.LoadScene(GameInfo.textIntroName);
    }
}
