using System.Collections.Generic;
using System.IO;
using DG.Tweening;
using GameUtils;
using TMPro;
using UnityEngine;
using UnityEngine.Video;

public enum Bet { None, Bug1, Bug2 }

namespace BeetleMania
{
    public class BettingScreenManager : SceneManager
    {
        // TODO: Make private & use [SerializeField]
        #region Inspector fields 
        public TextMeshProUGUI poolText;

        public SpawnPointBehaviour spawnPoint1, spawnPoint2;

        public GameObject bet1Gui, bet2Gui;
        public CanvasGroup bettingButtons;
        //public RectTransform bettingButtons;

        public Transform arena;
        public RectTransform TV;
        public VideoPlayer videoPlayer;
        public VideoClip staticVideo;
        public TextMeshProUGUI channelNumber;

        public TextMeshProUGUI nameBug1, nameBug2;
        public TextMeshProUGUI bioBug1, bioBug2;

        public RectTransform shopImage;

        // TODO: Remove
        //public Animator exitTransition;
        //public AudioSource exitAudio;

        public ArenasManager arenas;

        public CanvasGroup bettingInstructions;

        public AudioSource bugSelectionAudio; // Move to BugSelector?

        public AudioSource panelSfx;
        #endregion

        private BugSelector bs;
        private BugManager selectedBug;

        private TextMeshProUGUI bet1Text, bet2Text;

        private int bet = 0;

        private Bet activeBet;

        private const int incrementValue = 10;

        private const int odds = 2; // TEMP

        private bool isTVVisible;

        private const float bet1GuiStartPos = -500f, bet1GuiEndPos = -170.5f;
        private const float bet2GuiStartPos = 500f, bet2GuiEndPos = 170.5f;

        #region Video Stuff
        private List<string> replaysForSelectedBug = new List<string>();
        private int replayIdx = 0;
        #endregion

        private void Awake()
        {
            spawnPoint1.bugInfo = GameInfo.contestant1;
            spawnPoint2.bugInfo = GameInfo.contestant2;

            bs = FindObjectOfType<BugSelector>();

            bet1Text = bet1Gui.GetComponentInChildren<TextMeshProUGUI>();
            bet2Text = bet2Gui.GetComponentInChildren<TextMeshProUGUI>();

            bettingButtons.alpha = 0;

            nameBug1.text = GameInfo.contestant1.bugName;
            nameBug2.text = GameInfo.contestant2.bugName;

            bioBug1.text = "<b>Graduated from:</b>\n" + GameInfo.contestant1.university + "\n";
            bioBug2.text = "<b>Graduated from:</b>\n" + GameInfo.contestant2.university + "\n";

            bioBug1.text += "\n<b>Favourite sandwich:</b>\n" + GameInfo.contestant1.favouriteSandwich;
            bioBug2.text += "\n<b>Favourite sandwich:</b>\n" + GameInfo.contestant2.favouriteSandwich;

            // For demo (TEMP)
            if (GameInfo.currentRound == RoundNum.Zero)
            {
                GameInfo.lastActiveArenaIdx = 2;
            }
            else
            {
                // Randomise level (currently needs to be in Awake)
                GameInfo.lastActiveArenaIdx = Random.Range(0, arenas.arenas.Count);
            }
        }

        private void Update()
        {
            if (bs.SelectedBug != null && selectedBug != bs.SelectedBug)
            {
                ResetBet();
                selectedBug = bs.SelectedBug;

                //print(bs.SelectedBug + " is selected");
                bettingButtons.DOFade(1, 0.5f);
                bettingButtons.GetComponent<RectTransform>().DOAnchorPosY(50f, 0.5f);

                if (bs.SelectedBug.bugInfo == spawnPoint1.bugInfo)
                {
                    activeBet = Bet.Bug1;

                    ShowBetGui(bet1Gui, bet1GuiEndPos);
                    HideBetGui(bet2Gui, bet2GuiStartPos);
                }
                else if (bs.SelectedBug.bugInfo == spawnPoint2.bugInfo)
                {
                    activeBet = Bet.Bug2;

                    HideBetGui(bet1Gui, bet1GuiStartPos);
                    ShowBetGui(bet2Gui, bet2GuiEndPos);
                }

                if (!isTVVisible)
                {
                    ShowTV();
                    panelSfx.Play();
                }

                UpdateReplaysList(bs.SelectedBug.bugInfo.guid.ToString());

                bugSelectionAudio.Play();
            }
            else if (selectedBug != bs.SelectedBug)
            {
                ResetBet();
                selectedBug = null;

                activeBet = Bet.None;

                bettingButtons.DOFade(0, 0.25f);
                bettingButtons.GetComponent<RectTransform>().DOAnchorPosY(-75, 0.25f);
                HideBetGui(bet1Gui, bet1GuiStartPos);
                HideBetGui(bet2Gui, bet2GuiStartPos);

                if (isTVVisible)
                {
                    HideTV();
                }
            }

            bet1Text.text = GetBetText(bet);
            bet2Text.text = GetBetText(bet);

            channelNumber.text = "CH " + replayIdx.ToString();
        }

        public void StartMatch()
        {
            // Update betting info
            if (activeBet == Bet.Bug1)
            {
                GameInfo.bugBeingBetOn = spawnPoint1.bugInfo;
                GameInfo.betValue = bet; GameInfo.winnings = (bet * odds) + GameInfo.betValue;
                GameInfo.bugBeingBetOn.isMatch = true;
            }
            else if (activeBet == Bet.Bug2)
            {
                GameInfo.bugBeingBetOn = spawnPoint2.bugInfo;
                GameInfo.betValue = bet; GameInfo.winnings = (bet * odds) + GameInfo.betValue;
                GameInfo.bugBeingBetOn.isMatch = true;
            }
            else
            {
                GameInfo.bugBeingBetOn = null;
                GameInfo.betValue = 0; GameInfo.winnings = 0;
            }

            //print(GameInfo.bugBeingBetOn);
            //print(GameInfo.betValue);
            //print(GameInfo.winnings);

            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.matchName));
        }

        private void ShowBetGui(GameObject betGui, float endPos)
        {
            betGui.GetComponent<CanvasGroup>().DOFade(1, 0.5f);
            betGui.GetComponent<RectTransform>().DOAnchorPosX(endPos, 0.5f).SetEase(Ease.OutBack);
            betGui.SetActive(true);
        }

        private void HideBetGui(GameObject betGui, float startPos)
        {
            betGui.GetComponent<CanvasGroup>().DOFade(0, 0.25f);
            betGui.GetComponent<RectTransform>().DOAnchorPosX(startPos, 0.5f);
            ObjUtils.SetActiveAfterT(betGui, false, 0.25f);
        }

        private string GetBetText(int betValue)
        {
            //return "<color=#78AB46>" + betValue * odds + "</color>/" + betValue;
            return betValue.ToString();
        }

        public void ResetBet()
        {
            GameInfo.credit += bet;
            bet = 0;
        }

        public void IncrementBet()
        {
            if (GameInfo.credit > 0)
            {
                bet += incrementValue;
                GameInfo.credit -= incrementValue;
            }
        }

        public void DecrementBet()
        {
            if (bet > 0)
            {
                bet -= incrementValue;
                GameInfo.credit += incrementValue;
            }
        }

        public void ShowTV()
        {
            TV.DOAnchorPosY(100, 0.5f).SetEase(Ease.OutBounce);
            isTVVisible = true;
            //videoPlayer.playbackSpeed = 1;
            videoPlayer.Play();

            bettingInstructions.DOFade(0, 0.25f);
        }

        public void HideTV()
        {
            TV.DOAnchorPosY(400, 0.25f);
            isTVVisible = false;
            videoPlayer.Stop();

            bettingInstructions.DOFade(1, 0.5f);
        }

        public void RemoveSelection()
        {
            bs.Deselect();
        }

        #region Replay Stuff
        private void UpdateReplaysList(string guid)
        {
            //print(Application.persistentDataPath);

            replaysForSelectedBug.Clear();

            var info = new DirectoryInfo(Application.persistentDataPath + "/Captures");
            var fileInfo = info.GetFiles();

            foreach (var file in fileInfo)
            {
                //print(file.Name);

                if (file.Name.Contains(guid))
                {
                    replaysForSelectedBug.Add(file.FullName);
                }
            }

            replayIdx = 0;
            PlayVideo();
        }

        private void PlayVideo()
        {
            videoPlayer.Stop();
            if (replayIdx < replaysForSelectedBug.Count)
                PlayReplay(replaysForSelectedBug[replayIdx]);
            else
                PlayTVStatic();
        }

        private void PlayTVStatic()
        {
            //print("Playing TV static");
            videoPlayer.source = VideoSource.VideoClip;
            videoPlayer.clip = staticVideo;
            //videoPlayer.SetDirectAudioMute(0, true);
            videoPlayer.SetDirectAudioVolume(0, 0.25f);
            videoPlayer.playbackSpeed = 1;
            videoPlayer.Play();
        }

        private void PlayReplay(string moviePath)
        {
            videoPlayer.source = VideoSource.Url;
            videoPlayer.url = moviePath;

            //int pFrom = moviePath.IndexOf("<") + "<".Length;
            //int pTo = moviePath.LastIndexOf(">");
            //int timeScale = int.Parse(moviePath.Substring(pFrom, pTo - pFrom));
            //videoPlayer.playbackSpeed = 1 / (float)timeScale;
            //print("videoPlayer.playbackSpeed: " + videoPlayer.playbackSpeed);

            videoPlayer.Play();
        }

        public void ChannelUp()
        {
            replayIdx = replayIdx + 1 == 100 ? 0 : replayIdx + 1;
            PlayVideo();
        }

        public void ChannelDown()
        {
            replayIdx = replayIdx - 1 < 0 ? 99 : replayIdx - 1;
            PlayVideo();
        }
        #endregion

        public void ShowShop()
        {
            shopImage.DOAnchorPosY(0, 0.5f).SetEase(Ease.OutBounce);
        }

        public void HideShop()
        {
            shopImage.DOAnchorPosY(500f, 0.25f);
        }
    }
}
