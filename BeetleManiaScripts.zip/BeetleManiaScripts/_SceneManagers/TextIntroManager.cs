using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TextIntroManager : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public List<ChatTextInfo> chatTexts;

    public ChatTextInfo chatTextPrefab;
    public RectTransform chatInterface;

    public TextAsset introText;

    public TextMeshProUGUI creditValue;

    public Animator exitTransition;
    #endregion

    private int newestChatIdx = 0;
    private const int maxNumChats = 5;

    private string[] linesOfText;

    private bool canClick = true;

    private const int idxWhenCreditIsAdded = 9;

    private void Start()
    {
        linesOfText = introText.text.Split('\n');

        for (int i = 0; i < chatTexts.Count; i++)
        {
            chatTexts[i].text.text = linesOfText[i];
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(GameInfo.advanceKey))
        {
            if (!canClick) return;

            if (newestChatIdx < linesOfText.Length - 1)
            {
                if (newestChatIdx < chatTexts.Count - 1)
                    chatTexts[++newestChatIdx].gameObject.SetActive(true);
                else
                {
                    var chatText = Instantiate(chatTextPrefab, chatInterface);
                    chatText.text.text = linesOfText[++newestChatIdx];
                    chatTexts.Add(chatText);
                }

                if (newestChatIdx >= maxNumChats)
                {
                    for (int i = 0; i < newestChatIdx; i++)
                    {
                        chatTexts[i].GetComponent<RectTransform>().DOAnchorPosY(90, 0.5f).SetRelative(true);
                    }
                }

                float alpha = 1;

                for (int i = 1; i < maxNumChats; i++)
                {
                    if (newestChatIdx - i < 0) break;
                    alpha -= 0.2f;
                    chatTexts[newestChatIdx - i].bg.DOFade(alpha, 0.5f);
                }

                StartCoroutine("WaitBetweenClicks");

                if (newestChatIdx == idxWhenCreditIsAdded)
                    StartCoroutine(TextUtils.LerpNumericText(creditValue, 0, GameInfo.credit));
            }
            else
            {
                LoadScene(GameInfo.mainMenuName);
            }
        }
    }

    private void LoadScene(string sceneName)
    {
        exitTransition.gameObject.SetActive(true);
        StartCoroutine(SceneLoader.LoadSceneAfterT(sceneName,
            exitTransition.GetCurrentAnimatorStateInfo(0).length));
    }

    private IEnumerator WaitBetweenClicks() // TEMP
    {
        canClick = false;
        yield return new WaitForSeconds(0.5f);
        canClick = true;
    }

    public void LoadMainMenu()
    {
        LoadScene(GameInfo.mainMenuName);
    }
}
