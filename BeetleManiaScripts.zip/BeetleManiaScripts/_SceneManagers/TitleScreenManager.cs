using GameUtils;
using UnityEngine;

namespace BeetleMania
{
    public class TitleScreenManager : SceneManager
    {
        public void LoadPlayground()
        {
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.playgroundName));
        }

        public void LoadTournamentScreen()
        {
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.tournamentScreenName));
        }

        public void LoadPictorialIntroScene()
        {
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.textIntroName));
        }

        public void QuitGame()
        {
            Application.Quit();
        }
    }
}
