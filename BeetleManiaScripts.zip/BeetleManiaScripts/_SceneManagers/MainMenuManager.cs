using UnityEngine;

public class MainMenuManager : MonoBehaviour
{
    public Animator exitTransition;

    private void Update()
    {
        if (GameInfo.isDebug && Input.GetKeyDown(KeyCode.R))
        {
            //SceneManager.LoadScene(GameInfo.mainMenuName);

            exitTransition.gameObject.SetActive(true);
            StartCoroutine(SceneLoader.LoadSceneAfterT(GameInfo.mainMenuName,
                exitTransition.GetCurrentAnimatorStateInfo(0).length));
        }
    }

    public void LoadTournamentSelectionScreen()
    {
        //SceneLoader.LoadScene(GameInfo.tournamentSelectionScreenName);

        exitTransition.gameObject.SetActive(true);
        StartCoroutine(SceneLoader.LoadSceneAfterT(GameInfo.tournamentSelectionScreenName,
            exitTransition.GetCurrentAnimatorStateInfo(0).length));
    }
}
