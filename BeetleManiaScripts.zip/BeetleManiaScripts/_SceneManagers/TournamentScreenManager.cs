using Cinemachine;
using DG.Tweening;
using GameUtils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public enum RoundNum { Zero, One, Two, Three, Four, Five, Six, Fin }

public enum RoundLevel { Quaters, Semis, Finals, Champ }

namespace BeetleMania
{
    public class TournamentScreenManager : SceneManager
    {
        // TODO: Make private & use [SerializeField]
        #region Inspector fields 
        public List<PlatformBehaviour> platforms;

        public CinemachineVirtualCamera cam1, cam2;

        #region Betting UI
        public RectTransform allBets;
        public List<GameObject> bets;
        public RectTransform betValueGui, bettingButtons;

        public RectTransform leftButton, rightButton;

        public RectTransform currentBetLabel;

        public TextMeshProUGUI betValueText;
        #endregion

        public GameObject roundStartPlaque;
        public TextMeshProUGUI roundNumText, roundLevelText;

        public Light mainLight;

        public CanvasGroup bettingUI1, bettingUI2;
        public TextMeshProUGUI instructionalText;

        public Button confirmButton;

        public RectTransform bugTargeter; // For raycasting

        public TextMeshProUGUI rewardsText;
        public GameObject rewardsPlaque;

        public SFXPlayer BetSfx;

        public AudioSource panelSfx;

        public AudioSource bugSelectionAudio;

        public Image cross;
        #endregion

        private BugInfoGenerator big;

        private BugSelector bs;

        private int currentBetIdx = 0;

        private BugManager selectedBug;

        private int betValue = 0;
        private const int incrementValue = 10; // TODO: Move
        private BugInfo targetedBug = null;

        // Flags
        private bool areBugsInanimate;
        private bool isPlaqueVisible = true;
        private bool isBettingUIVisible;

        private void Awake()
        {
            Time.timeScale = 1; // TEMP

            bs = FindObjectOfType<BugSelector>();

            if (GameInfo.bugs.Count == 0)
            {
                big = GetComponent<BugInfoGenerator>();

                for (int i = 0; i < platforms.Count; i++)
                {
                    GameInfo.bugs.Add(big.GenerateBugInfo());
                }
            }
            else if (GameInfo.currentRound == RoundNum.Zero) // Shuffle existing list
            {
                CollectionUtils.Shuffle(GameInfo.bugs);
            }

            for (int i = 0; i < GameInfo.bugs.Count; i++)
            {
                platforms[i].spawnPoint.bugInfo = GameInfo.bugs[i];
            }

            if (GameInfo.currentRound == RoundNum.Zero)
            {
                bets[0].SetActive(true);
                panelSfx.Play();

                // Reset tournament related variables
                foreach (var bug in GameInfo.bugs)
                {
                    bug.hasLost = false;
                    bug.isSemis = false; bug.isFinals = false; bug.isChampion = false;
                    bug.isMatch = false;
                    bug.roundLevel = RoundLevel.Quaters;
                }

                roundLevelText.text = "Quarters";

                GameInfo.lastActiveArenaIdx = 0; // TEMP

                GameInfo.playSfx = true; GameInfo.playBgm = true; // TEMP
            }
            else
            {
                //roundNumText.text = "Round " + ((int)GameInfo.currentRound + 1);
                switch (GameInfo.currentRound)
                {
                    //case RoundNum.Zero:
                    case RoundNum.One:
                    case RoundNum.Two:
                    case RoundNum.Three:
                        roundLevelText.text = "Quarters";
                        break;
                    case RoundNum.Four:
                    case RoundNum.Five:
                        roundLevelText.text = "Semis";
                        break;
                    case RoundNum.Six:
                        roundLevelText.text = "Finals";
                        break;
                }

                if (GameInfo.currentRound != RoundNum.Fin)
                {
                    roundStartPlaque.SetActive(true);
                    isPlaqueVisible = true;
                    panelSfx.Play();
                    bettingUI1.DOFade(0, 0.25f); bettingUI2.DOFade(0, 0.25f);
                    instructionalText.DOFade(0, 0.25f);
                }

                mainLight.intensity = 0.25f;

                foreach (var bug in GameInfo.bugs) // TEMP
                {
                    bug.isMatch = false;
                }
            }

            roundNumText.text = "Round " + ((int)GameInfo.currentRound + 1); // TODO: Move

            if (GameInfo.currentRound == RoundNum.Fin)
            {
                int reward = 0;

                if (GameInfo.bugForSemis != null && GameInfo.bugForSemis.roundLevel >= RoundLevel.Semis)
                {
                    reward += GameInfo.winningsSemis;
                }

                if (GameInfo.bugForFinals != null && GameInfo.bugForFinals.roundLevel >= RoundLevel.Finals)
                {
                    reward += GameInfo.winningsFinals;
                }

                if (GameInfo.bugForChampion != null && GameInfo.bugForChampion.roundLevel >= RoundLevel.Champ)
                {
                    reward += GameInfo.winningsChampion;
                }

                GameInfo.credit += reward;


                rewardsText.text = "You win " + reward.ToString() + " <sprite index= 0>";
                rewardsPlaque.SetActive(true);
                isPlaqueVisible = true;

                panelSfx.Play();
            }

            AudioListener.volume = 1f; // TEMP
        }

        public void EndTournament()
        {
            GameInfo.contestant1 = null; GameInfo.contestant2 = null;
            GameInfo.currentRound = RoundNum.Zero;
            GameInfo.roundWinners = new List<BugInfo>(); GameInfo.roundLosers = new List<BugInfo>();
            GameInfo.bugIdx = 0; GameInfo.winnerIdx = 0;

            GameInfo.bugForSemis = null; GameInfo.bugForFinals = null; GameInfo.bugForChampion = null;
            GameInfo.bugBeingBetOn = null;

            foreach (var bug in GameInfo.bugs)
            {
                bug.numLives = 1;
                bug.isSemis = false; bug.isFinals = false; bug.isChampion = false;
                bug.isMatch = false;
            }

            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.titleScreenName));
        }

        private void Update()
        {
            if (bs.SelectedBug != selectedBug)
            {
                selectedBug = bs.SelectedBug;
                cam2.gameObject.SetActive(true);
                cam2.transform.DOMoveX(bs.SelectedBug.transform.position.x, 0.5f);

                if (isBettingUIVisible)
                    bugSelectionAudio.Play();
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                cam2.gameObject.SetActive(false);
                selectedBug = null;
            }

            if (!areBugsInanimate) // TEMP
            {
                foreach (var man in FindObjectsOfType<BugManager>()) // Just do once
                {
                    man.IsInanimate = true;
                }

                areBugsInanimate = true;
            }

            betValueText.text = betValue.ToString();

            TargetBug();

            // TEMP
            if (targetedBug != null)
            {
                if ((targetedBug == GameInfo.bugForSemis || targetedBug == GameInfo.bugForFinals) && !isPlaqueVisible)
                {
                    cross.DOFade(1, 0.5f);
                    bettingUI2.interactable = false;
                }
                else
                {
                    cross.DOFade(0, 0.25f);
                    bettingUI2.interactable = true;
                }
            }

            if (bs.SelectedBug != null && bs.SelectedBug.bugInfo != targetedBug)
            {
                if (targetedBug != null)
                    StartCoroutine(HideCoins());
                ResetBetValue();
            }
        }

        private void TargetBug()
        {
            Ray ray = Camera.main.ScreenPointToRay(bugTargeter.position);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.CompareTag("target"))
                {
                    targetedBug = hit.collider.GetComponent<BugManager>().bugInfo;
                }
            }
        }

        public void ResetBetValue()
        {
            GameInfo.credit += betValue;
            betValue = 0;
        }

        public void IncrementBetValue()
        {
            if (GameInfo.credit > 0)
            {
                betValue += incrementValue;
                GameInfo.credit -= incrementValue;
                BetSfx.PlaySFX();
            }

            ShowCoins();
        }

        public void DecrementBetValue()
        {
            if (betValue > 0)
            {
                betValue -= incrementValue;
                GameInfo.credit += incrementValue;
                BetSfx.PlaySFX();
            }

            ShowCoins();
        }

        #region Show/hide coins (unused)
        private IEnumerator HideCoins()
        {
            var coinSet = GetCorrespondingPlatform(targetedBug).coins[currentBetIdx];

            List<GameObject> coins = new List<GameObject>();

            foreach (Transform coin in coinSet.transform)
            {
                if (coin.gameObject.activeSelf)
                    coins.Add(coin.gameObject);
            }

            //print("coins.Count: " + coins.Count);

            for (int i = coins.Count - 1; i >= 0; i--)
            {
                coins[i].SetActive(false);
                yield return new WaitForSeconds(0.15f);
            }

            coinSet.SetActive(false);
        }

        private void ShowCoins()
        {
            if (targetedBug == null) return;

            var coinSet = GetCorrespondingPlatform(targetedBug).coins[currentBetIdx];

            foreach (Transform coin in coinSet.transform)
            {
                coin.gameObject.SetActive(false);
            }

            //int numCoins = betValue / 10;
            for (int i = 0; i < betValue / 10; i++)
            {
                coinSet.transform.GetChild(i).gameObject.SetActive(true);
            }

            coinSet.SetActive(true);
        }

        public PlatformBehaviour GetCorrespondingPlatform(BugInfo bug)
        {
            PlatformBehaviour correspondingPlatform = null;

            foreach (var platform in platforms)
            {
                if (platform.spawnPoint.bugInfo == bug)
                {
                    correspondingPlatform = platform;
                    break;
                }
            }

            return correspondingPlatform;
        }
        #endregion

        public void ConfirmBet()
        {
            if (targetedBug == null)
            {
                print("Failed to target bug!");
            }

            // TODO: Use enum & don't hardcode odds
            if (currentBetIdx == 0)
            {
                GameInfo.bugForSemis = targetedBug;
                GameInfo.winningsSemis = (betValue * 3) + betValue;
                targetedBug.isSemis = true;
            }
            else if (currentBetIdx == 1)
            {
                GameInfo.bugForFinals = targetedBug;
                GameInfo.winningsFinals = (betValue * 4) + betValue;
                targetedBug.isFinals = true;
            }
            else if (currentBetIdx == 2)
            {
                GameInfo.bugForChampion = targetedBug;
                GameInfo.winningsChampion = (betValue * 5) + betValue;
                targetedBug.isChampion = true;
            }

            betValue = 0;

            ShowNextBet();
        }

        public void StartRound()
        {
            UpdateContestantInfo();
            LoadBettingScreen();
        }

        private static void UpdateContestantInfo()
        {
            switch (GameInfo.currentRound)
            {
                case RoundNum.Zero:
                case RoundNum.One:
                case RoundNum.Two:
                case RoundNum.Three:
                    GameInfo.contestant1 = GameInfo.bugs[GameInfo.bugIdx++];
                    GameInfo.contestant2 = GameInfo.bugs[GameInfo.bugIdx++];
                    break;
                case RoundNum.Four:
                case RoundNum.Five:
                case RoundNum.Six:
                    GameInfo.contestant1 = GameInfo.roundWinners[GameInfo.winnerIdx++];
                    GameInfo.contestant2 = GameInfo.roundWinners[GameInfo.winnerIdx++];
                    break;
            }
        }

        public void SkipRound()
        {
            GameInfo.skipRound = true;
            UpdateContestantInfo();
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.matchName));
        }

        public void LoadBettingScreen()
        {
            StartCoroutine(SceneUtils.LoadSceneWithTransition(GameInfo.bettingScreenName));
        }

        public void CloseAllBets()
        {
            allBets.DOScale(0, 0.5f).SetEase(Ease.InBack);

            cam2.gameObject.SetActive(false);

            StartCoroutine(SwitchLights());

            //isPlaqueVisible = true;
        }

        private IEnumerator SwitchLights() // TODO: Rename
        {
            yield return new WaitForSeconds(0.5f);
            DimMainLight();
            for (int i = 0; i < 2; i++)
            {
                platforms[i].Brighten();
            }

            roundNumText.text = "Round " + (int)GameInfo.currentRound + 1;
            roundStartPlaque.SetActive(true);
            isPlaqueVisible = true;

            bettingUI1.DOFade(0, 0.25f); bettingUI2.DOFade(0, 0.25f);
            instructionalText.DOFade(0, 0.25f);
        }

        private void HideCurrentBet()
        {
            for (int i = 0; i < currentBetIdx; i++) // TEMP
            {
                bets[i].SetActive(false);
            }
            bets[currentBetIdx].GetComponent<RectTransform>().DOScale(0, 0.5f).SetEase(Ease.InBack);

            isPlaqueVisible = false;
        }

        public void ShowNextBet()
        {
            if (currentBetIdx < bets.Count - 1)
            {
                bettingUI1.DOFade(0, 0.25f); bettingUI2.DOFade(0, 0.25f);
                instructionalText.DOFade(0, 0.25f);
                bets[++currentBetIdx].SetActive(true);

                panelSfx.Play();

                isPlaqueVisible = true;
            }
            else
            {
                CloseAllBets();
            }
        }

        public void ZoomToFirstBug()
        {
            bs.SelectedBug = platforms[0].spawnPoint.AssociatedBug;
            HideCurrentBet();
            StartCoroutine(ShowBetGuiAfterCamHasBlended());
        }

        private IEnumerator ShowBetGuiAfterCamHasBlended()
        {
            while (CinemachineCore.Instance.IsLive(cam1)) { yield return null; }
            ShowBetGui();
            bugSelectionAudio.Play();
        }

        private void ShowBetGui()
        {
            if (currentBetIdx == 0 || !isBettingUIVisible)
            {
                betValueGui.GetComponent<CanvasGroup>().DOFade(1, 0.5f);
                betValueGui.GetComponent<RectTransform>().DOAnchorPosX(30, 0.5f).SetEase(Ease.OutBack);

                bettingButtons.GetComponent<RectTransform>().DOAnchorPosY(20, 0.5f);

                leftButton.GetComponent<RectTransform>().DOAnchorPosX(0, 0.5f);
                rightButton.GetComponent<RectTransform>().DOAnchorPosX(0, 0.5f);

                currentBetLabel.DOAnchorPosX(10, 0.5f);

                bettingUI1.DOFade(1, 0.5f); bettingUI2.DOFade(1, 0.5f);
                instructionalText.DOFade(1, 0.5f);

                isBettingUIVisible = true;
            }
            else
            {
                bettingUI1.DOFade(1, 0.5f); bettingUI2.DOFade(1, 0.5f);
                instructionalText.DOFade(1, 0.5f);
            }
        }

        private void DimMainLight()
        {
            mainLight.DOIntensity(0.25f, 0.5f);
        }
    }
}
