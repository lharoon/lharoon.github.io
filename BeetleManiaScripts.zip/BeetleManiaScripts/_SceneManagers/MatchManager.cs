using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using GameUtils;
using RenderHeads.Media.AVProMovieCapture;
using TMPro;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

namespace BeetleMania
{
    public class MatchManager : SceneManager
    {
        // TODO: Make private & use [SerializeField]
        #region Inspector fields 
        public SpawnPointBehaviour spawnPoint1, spawnPoint2;
        public TextMeshProUGUI contestant1NumLives, contestant2NumLives;
        public TextMeshProUGUI roundWinnerText, winningsText;
        public CanvasGroup roundEndGroup;
        public RectTransform roundEndUI;

        public GameObject enterTransition;

        public GameObject matchInProgressBg;
        public TextMeshProUGUI matchInProgressText;

        public AudioSource panelSfx, winMoneySfx;

        public Toggle soundToggle, bgmToggle; // TEMP

        public AudioSource bgm;

        [SerializeField]
        private AudioMixer audioMixer;
        #endregion

        private CaptureFromCamera recorder;

        private bool hasRoundEnded;

        private void Awake()
        {
            spawnPoint1.bugInfo = GameInfo.contestant1;
            spawnPoint2.bugInfo = GameInfo.contestant2;

            recorder = FindObjectOfType<CaptureFromCamera>();

            soundToggle.isOn = GameInfo.playSfx;
            bgmToggle.isOn = GameInfo.playBgm;
        }

        private void Start()
        {
            if (GameInfo.playBgm)
                bgm.Play();

            GameInfo.isMatchUnderway = true;

            if (GameInfo.skipRound)
            {
                matchInProgressBg.SetActive(true);
                matchInProgressText.gameObject.SetActive(true);
                Time.timeScale = 16;

                AudioListener.volume = 0f; // TEMP
            }
            else
            {
                //enterTransition.enabled = true;
                enterTransition.SetActive(true);
                recorder.FilenamePrefix = GameInfo.contestant1.guid + "_v_" + GameInfo.contestant2.guid;
                //+ "<" + Time.timeScale.ToString() + ">"; // timeScale
                recorder.StartCapture();
            }
        }

        private void Update()
        {
            contestant1NumLives.text = GetNumLivesText(GameInfo.contestant1);
            contestant2NumLives.text = GetNumLivesText(GameInfo.contestant2);

            if (!hasRoundEnded)
            {
                if (GameInfo.contestant1.numLives == 0)
                    EndRound(GameInfo.contestant2, GameInfo.contestant1);
                else if (GameInfo.contestant2.numLives == 0)
                    EndRound(GameInfo.contestant1, GameInfo.contestant2);
            }

            // TEMP
            if (audioMixer != null)
            {
                audioMixer.SetFloat("sfxVolume", !GameInfo.playSfx ? -80f : 0f);
                audioMixer.SetFloat("bgmVolume", !GameInfo.playBgm ? -80f : 0f);
            }
        }

        private string GetNumLivesText(BugInfo bug)
        {
            return bug.bugName + "\n" + bug.numLives;
        }

        private void EndRound(BugInfo winner, BugInfo loser)
        {
            bgm.DOFade(0, 0.5f);

            Time.timeScale = 1;

            #region Compute round winnings
            int roundWinnings = 0;

            if (GameInfo.bugBeingBetOn == winner)
                roundWinnings += GameInfo.winnings;

            switch (GameInfo.currentRound)
            {
                case RoundNum.Zero:
                case RoundNum.One:
                case RoundNum.Two:
                case RoundNum.Three:
                    if (GameInfo.bugForSemis == winner)
                    {
                        roundWinnings += GameInfo.winningsSemis;
                        winner.isSemis = false; // Remove flag
                    }
                    break;
                case RoundNum.Four:
                case RoundNum.Five:
                    if (GameInfo.bugForFinals == winner)
                    {
                        roundWinnings += GameInfo.winningsFinals;
                        winner.isFinals = false; // Remove flag
                    }
                    break;
                case RoundNum.Six:
                    if (GameInfo.bugForChampion == winner)
                    {
                        roundWinnings += GameInfo.winningsChampion;
                    }
                    break;
            }

            GameInfo.credit += roundWinnings;
            #endregion

            GameInfo.roundWinners.Add(winner);
            GameInfo.roundLosers.Add(loser);

            hasRoundEnded = true;

            GameInfo.isMatchUnderway = false;

            loser.hasLost = true; // TEMP

            winner.roundLevel++; // TEMP

            if (GameInfo.skipRound)
            {
                AdvanceRound();
            }

            roundEndUI.DOAnchorPosY(0, 0.5f).SetEase(Ease.OutBounce);
            panelSfx.Play();

            roundWinnerText.text = GetRoundWinnerText(winner);
            winningsText.text = "You win " + roundWinnings + " <sprite index= 0>";
            if (roundWinnings > 0)
                winMoneySfx.Play();

            StartCoroutine(StopCaptureAfterT(3f));
        }

        private string GetRoundWinnerText(BugInfo bug)
        {
            return bug.bugName + " wins!";
        }

        private IEnumerator StopCaptureAfterT(float t)
        {
            yield return new WaitForSeconds(t);
            recorder.StopCapture();
        }

        public void ForceEndRound()
        {
            GameInfo.contestant1.numLives = 0;
        }

        public void AdvanceRound()
        {
            GameInfo.currentRound++;

            // Reset lives count
            GameInfo.contestant1.numLives = 1; GameInfo.contestant2.numLives = 1; // TEMP

            LoadScene(GameInfo.tournamentScreenName);
        }

        public void EndTournament() // TODO: Move
        {
            GameInfo.contestant1 = null; GameInfo.contestant2 = null;
            GameInfo.currentRound = RoundNum.Zero;
            GameInfo.roundWinners = new List<BugInfo>(); GameInfo.roundLosers = new List<BugInfo>();
            GameInfo.bugIdx = 0; GameInfo.winnerIdx = 0;

            GameInfo.bugForSemis = null; GameInfo.bugForFinals = null; GameInfo.bugForChampion = null;
            GameInfo.bugBeingBetOn = null;

            foreach (var bug in GameInfo.bugs)
            {
                bug.numLives = 1;
                bug.isSemis = false; bug.isFinals = false; bug.isChampion = false;
                bug.isMatch = false;
            }

            LoadScene(GameInfo.titleScreenName);
        }

        private void LoadScene(string sceneName)
        {
            if (GameInfo.skipRound)
            {
                GameInfo.skipRound = false;
                matchInProgressText.DOFade(0, 0.25f);
                StartCoroutine(SceneLoader.LoadSceneAfterT(sceneName, 0.25f));
            }
            else
            {
                StartCoroutine(SceneUtils.LoadSceneWithTransition(sceneName));
            }
        }
    }
}
