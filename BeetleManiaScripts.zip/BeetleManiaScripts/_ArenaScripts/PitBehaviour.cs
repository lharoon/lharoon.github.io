using UnityEngine;

public class PitBehaviour : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("radar"))
        {
            var bug = other.GetComponent<BugManager>();
            if (bug != null)
                bug.Kill();
            //else
            //    Destroy(other.gameObject);
        }
    }
}
