using UnityEngine;

public class DotSpawner : MonoBehaviour
{
    public float minX, maxX, minZ, maxZ;
    public float y = 2;
    public float gapBetweenDots;

    public Transform dotPrefab;

    private void Start()
    {
        for (float z = minZ; z <= maxZ; z += gapBetweenDots)
        {
            for (float x = minX; x <= maxX; x += gapBetweenDots)
            {
                var dot = Instantiate(dotPrefab, new Vector3(x, y, z), Quaternion.identity);
                dot.parent = transform;
            }
        }
    }
}
