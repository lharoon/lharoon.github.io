using UnityEngine;

public class DotKiller : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("barrier"))
            Destroy(transform.parent.gameObject);
    }
}
