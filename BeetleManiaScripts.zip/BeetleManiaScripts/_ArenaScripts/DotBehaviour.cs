using DG.Tweening;
using System.Collections;
using UnityEngine;

public class DotBehaviour : MonoBehaviour
{
    public float speed = 30f;

    public bool isRespawnable = true;

    private const float dim = 0.25f, dFromFloor = 0.25f;

    private void Start()
    {
        GroundTransform();
    }

    private void GroundTransform()
    {
        RaycastHit hit;
        Physics.Raycast(transform.position,
            transform.TransformDirection(Vector3.down),
            out hit, Mathf.Infinity);
        if (hit.collider != null)
        {
            if (hit.collider.CompareTag("floor"))
                transform.position = hit.point + (Vector3.up * dFromFloor);
            else
                Destroy(gameObject);
        }
    }

    private void Update()
    {
        float deg = speed * Time.deltaTime;
        transform.Rotate(deg, 0, deg);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("target"))
        {
            ToggleVisibility(false, Vector3.zero, "Untagged");
            if (isRespawnable)
                StartCoroutine(ShowAfterT(5f));
        }
    }

    private void ToggleVisibility(bool isVisible, Vector3 newSize, string newTag)
    {
        GetComponent<Collider>().enabled = isVisible;
        transform.DOScale(newSize, 0.25f);
        tag = newTag;
    }

    private IEnumerator ShowAfterT(float t)
    {
        yield return new WaitForSeconds(t);
        ToggleVisibility(true, new Vector3(dim, dim, dim), "dot");
    }
}
