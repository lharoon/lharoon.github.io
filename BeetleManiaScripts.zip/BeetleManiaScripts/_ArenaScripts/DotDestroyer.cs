using UnityEngine;

public class DotDestroyer : MonoBehaviour // TEMP
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("dot"))
            Destroy(other.gameObject);
    }
}
