using System.Collections.Generic;
using GameUtils;
using UnityEngine;

namespace BeetleMania
{
    public class ArenasManager : MonoBehaviour
    {
        public List<GameObject> arenas;

        private int activeArenaIdx;
        public int ActiveArenaIdx { get { return activeArenaIdx; } }

        private void Start()
        {
            activeArenaIdx = GameInfo.lastActiveArenaIdx;

            foreach (var arena in arenas)
            {
                arena.SetActive(false);
            }

            arenas[activeArenaIdx].SetActive(true);
        }

        private void RestartScene() // Move?
        {
            var activeScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            StartCoroutine(SceneUtils.LoadSceneWithTransition(activeScene.name));
        }

        public void ShowPreviousArena()
        {
            GameInfo.lastActiveArenaIdx = activeArenaIdx == 0 ?
                activeArenaIdx = arenas.Count - 1 : activeArenaIdx - 1;
            RestartScene();
        }

        public void ShowNextArena()
        {
            GameInfo.lastActiveArenaIdx = activeArenaIdx == arenas.Count - 1 ?
                activeArenaIdx = 0 : activeArenaIdx + 1;
            RestartScene();
        }
    }
}
