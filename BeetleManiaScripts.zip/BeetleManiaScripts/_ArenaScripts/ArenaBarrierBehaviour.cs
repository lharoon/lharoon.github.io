using UnityEngine;

public class ArenaBarrierBehaviour : MonoBehaviour
{
    public int numBarriers = 45;
    public float radius = 6f;

    public Transform barrierSphere;

    private void Start()
    {
        CreateBarrier(numBarriers, transform.position, radius);
    }

    // http://answers.unity.com/answers/1661781/view.html
    public void CreateBarrier(int num, Vector3 point, float radius)
    {
        for (int i = 0; i < num; i++)
        {
            /* Distance around the circle */
            var radians = 2 * Mathf.PI / num * i;

            /* Get the vector direction */
            var vertical = Mathf.Sin(radians);
            var horizontal = Mathf.Cos(radians);

            var spawnDir = new Vector3(horizontal, 0, vertical);

            /* Get the spawn position */
            var spawnPos = point + spawnDir * radius; // Radius is just the distance away from the point

            /* Now spawn */
            var sphere = Instantiate(barrierSphere, spawnPos, Quaternion.identity);

            sphere.parent = transform;

            /* Rotate the enemy to face towards player */
            sphere.transform.LookAt(point);

            /* Adjust height */
            sphere.transform.Translate(new Vector3(0, sphere.transform.localScale.y / 2, 0));
        }

        transform.position = new Vector3(point.x, -0.75f, point.z); // TEMP
    }
}
