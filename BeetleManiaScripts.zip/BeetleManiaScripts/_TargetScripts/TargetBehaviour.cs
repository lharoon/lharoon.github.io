using DG.Tweening;
using UnityEngine;

public class TargetBehaviour : MonoBehaviour // CubeBehaviour
{
    public GameObject waterCollisionFxPrefab;
    public Transform model;

    public bool IsOutOfBounds { get; set; }
    public float Size { get; set; }

    private void Start()
    {
        model.transform.DOScale(1, 0.5f);
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("boundary"))
            DestroyTarget();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("barrier"))
            DestroyTarget();

        if (collision.gameObject.CompareTag("water"))
            PlayWaterSinkAnimation(collision.GetContact(0).point);
    }

    private void DestroyTarget()
    {
        tag = "Untagged";
        //transform.DOScale(Vector3.zero, 0.5f);
        //Destroy(gameObject, 0.5f);
        Destroy(gameObject);
    }

    private void PlayWaterSinkAnimation(Vector3 pos)
    {
        var waterCollisionFx = Instantiate(waterCollisionFxPrefab, pos, Quaternion.identity);
        Destroy(waterCollisionFx, 3f);
        model.transform.DOMoveY(-0.7f, 0.5f).SetRelative(true).OnComplete(PlayRiseToSurfaceAnimation);
    }

    private void PlayRiseToSurfaceAnimation()
    {
        model.transform.DOMoveY(0.2f, 1f).SetRelative(true);
    }
}
