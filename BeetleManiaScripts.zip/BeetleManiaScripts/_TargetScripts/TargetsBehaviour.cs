using DG.Tweening;
using UnityEngine;

public class TargetsBehaviour : MonoBehaviour
{
    public RectTransform showButton, hideButton;

    public void Show()
    {
        showButton.DOAnchorPosY(-50f, 0.5f);
        hideButton.DOScale(1, 0.5f);
        transform.DOMoveZ(-7.5f, 0.5f);
    }

    public void Hide()
    {
        showButton.DOAnchorPosY(10f, 0.5f);
        hideButton.DOScale(0, 0.5f);
        transform.DOMoveZ(-10f, 0.5f);
    }
}
