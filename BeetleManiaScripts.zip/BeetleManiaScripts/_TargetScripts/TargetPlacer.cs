using UnityEngine;

public class TargetPlacer : MonoBehaviour
{
    public float scaleFactor = 0.1f;

    public Transform target1Prefab, target2Prefab;
    public Material target1Material, target2Material;

    private Transform targetPrefab;
    private Vector3 worldPosition;

    private void Start()
    {
        targetPrefab = target1Prefab;
    }

    void Update()
    {
        Plane plane = new Plane(Vector3.up, 0);

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (plane.Raycast(ray, out float distance))
        {
            worldPosition = ray.GetPoint(distance);
        }

        transform.position = new Vector3(worldPosition.x, transform.position.y,
            worldPosition.z);

        if (Input.GetMouseButtonUp(0))
        {
            var target = Instantiate(targetPrefab, worldPosition + (Vector3.up * 2f), Quaternion.identity);
            Vector3 size = transform.localScale;
            size.y = size.x;
            target.GetComponent<TargetBehaviour>().Size = transform.localScale.x;
            //target.parent = tm.arenas[tm.ActiveArenaIdx].transform;

            Destroy(gameObject);
        }

        float scale = Input.mouseScrollDelta.y * scaleFactor;
        Vector3 newSize = transform.localScale + (Vector3.one * scale);
        newSize.y = transform.localScale.y;
        transform.localScale = newSize;
    }
}
