using System.Collections.Generic;
using UnityEngine;

public class RecordingTest : MonoBehaviour
{
    public GameObject spawnPointPrefab;

    public List<GameObject> spawnPoints;

    private Vector3 spawnPointPos;

    private bool isEnabled;

    private void Update()
    {
        if (!isEnabled) return;

        var spawnPoints = GameObject.FindGameObjectsWithTag("spawn-point");

        if (spawnPoints.Length < 2)
        {
            Instantiate(spawnPointPrefab, spawnPointPos, Quaternion.identity);
        }
    }

    public void EnableTest()
    {
        isEnabled = !isEnabled;

        foreach (var sp in spawnPoints)
            sp.SetActive(isEnabled);

        if (isEnabled)
            spawnPointPos = GameObject.FindGameObjectWithTag("spawn-point").transform.position;
    }
}
