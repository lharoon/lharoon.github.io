using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;

public class TestManager : MonoBehaviour
{
    public TextMeshProUGUI buttonText;
    public Transform arenaContainer;
    public List<GameObject> arenas;
    public List<GameObject> navButtons;

    public Transform bugPrefab;

    public bool hasTestStarted, hasMatchStarted;

    private int activeArenaIdx;

    private BugSelector bs;

    private List<BugInfo> bugInfos = new List<BugInfo>();
    public List<Transform> spawnPositions = new List<Transform>();

    private GameManager gm;

    public TextMeshProUGUI winText;

    public AudioSource fightBgm;

    public List<TextMeshProUGUI> numLives;

    public int ActiveArenaIdx { get => activeArenaIdx; private set => activeArenaIdx = value; }

    private void Start()
    {
        bs = FindObjectOfType<BugSelector>();
        gm = FindObjectOfType<GameManager>();
    }

    private void Update()
    {
        if (hasMatchStarted)
        {
            if (FindObjectsOfType<BugManager>().Length == 1) // Do once
            {
                var winner = FindObjectOfType<BugManager>();
                winText.text = winner.bugInfo.bugName + " wins!";
                winText.gameObject.SetActive(true);
                fightBgm.Stop();
            }

            for (int i = 0; i < bugInfos.Count; i++)
            {
                numLives[i].text = bugInfos[i].bugName + "\n" + bugInfos[i].numLives;
            }
        }
    }

    public void StartTest()
    {
        if (!hasTestStarted)
        {
            // Destroy existing targets
            foreach (var target in GameObject.FindGameObjectsWithTag("target"))
            {
                if (target.transform.parent != null)
                    Destroy(target.transform.parent.gameObject);
                else
                    Destroy(target.gameObject);
            }

            // Show arenas & instantiate bugs
            foreach (var arena in arenas)
            {
                arena.SetActive(true);
                SpawnBug(arena.transform);
            }

            // Show arena navigation buttons
            foreach (var button in navButtons)
            {
                button.SetActive(true);
            }

            // Change button text to start
            buttonText.text = "Start";

            hasTestStarted = true;
        }
        else if (!hasMatchStarted)
        {
            gm.ResetCam();
            ShowNumLives(true);
            //StartMatch();
            StartCoroutine(StartMatch());

            // Change button text to restart
            buttonText.text = "Restart";
        }
        else // Restart
        {
            fightBgm.Stop();

            winText.gameObject.SetActive(false);

            gm.ResetCam();

            ShowNumLives(false);

            hasMatchStarted = false;

            // Destroy existing targets
            foreach (var target in GameObject.FindGameObjectsWithTag("target"))
            {
                if (target.transform.parent != null)
                    Destroy(target.transform.parent.gameObject);
                else
                    Destroy(target.gameObject);
            }

            // Show arenas & reinstantiate bugs
            for (int i = 0; i < arenas.Count; i++)
            {
                arenas[i].SetActive(true);
                SpawnBug(arenas[i].transform, bugInfos[i]);
            }

            // Show arena navigation buttons
            foreach (var button in navButtons)
            {
                button.SetActive(true);
            }

            foreach (var bug in bugInfos)
            {
                bug.numLives = 2;
            }

            // Change button text to start
            buttonText.text = "Start";
        }
    }

    private void ShowNumLives(bool show)
    {
        foreach (var nl in numLives)
            nl.gameObject.SetActive(show);
    }

    private void SpawnBug(Transform spawnPos) // TODO
    {
        var bug = Instantiate(bugPrefab);

        Vector3 bugPos = spawnPos.position;
        bugPos.y = 0;
        bug.transform.position = bugPos;

        bug.transform.parent = spawnPos;

        var bm = bug.GetComponentInChildren<BugManager>();
        bm.RandomiseAttributeValues();
        bm.bugInfo.bugName = BugNameGenerator.GetRandomName();
        bm.bmm.SetRandom();

        bs.AddBug(bm);

        bugInfos.Add(bm.bugInfo);
    }

    private void SpawnBug(Transform spawnPos, BugInfo bugInfo) // TODO
    {
        var bug = Instantiate(bugPrefab);

        Vector3 bugPos = spawnPos.position;
        bugPos.y = 0;
        bug.transform.position = bugPos;

        bug.transform.parent = spawnPos;

        var bm = bug.GetComponentInChildren<BugManager>();
        bm.bugInfo = bugInfo;
        bm.SetModelAndMat();
        bs.AddBug(bm);
    }

    private IEnumerator StartMatch()
    {
        // Show arena navigation buttons
        foreach (var button in navButtons)
        {
            button.SetActive(false);
        }

        // Show UI for bugs (lives)

        // Delete all targets
        foreach (var target in GameObject.FindGameObjectsWithTag("target"))
        {
            if (target.transform.parent != null)
                Destroy(target.transform.parent.gameObject);
            else
                Destroy(target.gameObject);
        }

        // Hide other arenas
        arenas[1].SetActive(false);
        arenas[2].SetActive(false);

        // Move back to arena 0
        ActiveArenaIdx = 0;
        UpdateArenaPos();

        yield return new WaitForSeconds(0.5f);

        // Reinstantiate targets
        for (int i = 0; i < bugInfos.Count; i++)
        {
            SpawnBug(spawnPositions[i], bugInfos[i]);
        }

        fightBgm.Play();

        yield return new WaitForSeconds(0.5f);

        hasMatchStarted = true;
    }

    public void MoveRight()
    {
        gm.ResetCam();
        ActiveArenaIdx++;
        if (ActiveArenaIdx == arenas.Count) ActiveArenaIdx = 0;
        UpdateArenaPos();
    }

    public void MoveLeft()
    {
        gm.ResetCam();
        ActiveArenaIdx--;
        if (ActiveArenaIdx < 0) ActiveArenaIdx = arenas.Count - 1;
        UpdateArenaPos();
    }

    private void UpdateArenaPos()
    {
        float xPos = 0;

        switch (ActiveArenaIdx)
        {
            case 0:
                //xPos = 0;
                break;
            case 1:
                xPos = -16;
                break;
            case 2:
                xPos = -32;
                break;
            default:
                break;
        }

        arenaContainer.DOMoveX(xPos, 0.5f);
    }
}
