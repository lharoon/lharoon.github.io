using DG.Tweening;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AttributeTests : MonoBehaviour
{
    public List<GameObject> tests;
    public List<string> instructionStrings;

    public GameObject secondaryCam, generators;

    public GameObject nextButton;
    public TextMeshProUGUI buttonText, nextButtonText;
    public List<TextMeshProUGUI> allTexts;
    public TextMeshProUGUI instructionsText, resultText;

    public TextMeshProUGUI winText, loseText;

    private BugSelector bs;

    private int currentTestIdx;
    private BugInfo answer;

    private bool haveTestsStarted;
    private GameObject activeTest;

    private void Awake()
    {
        bs = FindObjectOfType<BugSelector>();
    }

    private void ShowText(TextMeshProUGUI text)
    {
        text.DOFade(1, 0.25f);
    }

    private void HideText(TextMeshProUGUI text)
    {
        text.DOFade(0, 0.25f);
    }

    private void Update()
    {
        if (!haveTestsStarted) return;

        if (bs.SelectedBug != null)
        {
            if (bs.SelectedBug.bugInfo.guid == answer.guid)
            {
                HideText(loseText);
                ShowText(winText);
            }
            else
            {
                HideText(winText);
                ShowText(loseText);
            }
        }
    }

    public void RunTest()
    {
        CleanUp();

        // Disable playground features
        secondaryCam.SetActive(false);
        generators.SetActive(false);

        // Update button text
        buttonText.text = "Rerun";

        nextButton.SetActive(true);

        // Show test instructions
        FadeTexts(true); // Only do once
        instructionsText.text = instructionStrings[currentTestIdx];
        resultText.text = "Pending";

        // Activate test
        //tests[currentTestIdx].SetActive(true);
        activeTest = Instantiate(tests[currentTestIdx]);

        // Get bug info
        var sps = activeTest.GetComponentsInChildren<SpawnPointBehaviour>();

        // Get solution
        answer = sps[0].bugInfo.attributes[currentTestIdx].value >
            sps[1].bugInfo.attributes[currentTestIdx].value ?
            sps[0].bugInfo : sps[1].bugInfo;

        haveTestsStarted = true;
    }

    private void CleanUp()
    {
        HideText(winText);
        HideText(loseText);

        // Destroy existing targets
        foreach (var target in GameObject.FindGameObjectsWithTag("target"))
        {
            if (target.transform.parent != null)
                Destroy(target.transform.parent.gameObject);
            else
                Destroy(target.gameObject);
        }

        // Destroy existing spawn points
        foreach (var spawnPoint in FindObjectsOfType<SpawnPointBehaviour>())
        {
            Destroy(spawnPoint.gameObject);
        }

        // Reset selection
        bs.SelectedBug = null;

        Destroy(activeTest);
    }

    public void RunNextTest()
    {
        //if (currentTestIdx > 0)
        //    tests[currentTestIdx - 1].SetActive(false);

        currentTestIdx++;
        RunTest();

        if (currentTestIdx == tests.Count - 1)
        {
            nextButtonText.text = "Restart";
            currentTestIdx = 0;
        }
    }

    private void FadeTexts(bool isShow)
    {
        float tgt = isShow ? 1 : 0;

        foreach (var text in allTexts)
        {
            text.DOFade(tgt, 0.5f);
        }
    }
}
