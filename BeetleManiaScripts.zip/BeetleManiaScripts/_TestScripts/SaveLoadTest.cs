using System.Linq;
using TMPro;
using UnityEngine;

public class SaveLoadTest : MonoBehaviour
{
    public TMP_InputField input;

    public GameObject bugPrefab;

    private BugDataManager bg;
    private BugSelector bs;

    private const string allNamesKey = "allNames";

    private void Start()
    {
        bg = FindObjectOfType<BugDataManager>();
        bs = FindObjectOfType<BugSelector>();
    }

    public void SaveBug()
    {
        if (bs.SelectedBug == null)
        {
            print("No bug selected!");
            return;
        }

        bg.SaveToPP(bs.SelectedBug.bugInfo);
    }

    public void LoadAndInstantiateBug()
    {
        string[] names = PlayerPrefs.GetString(allNamesKey).Split(' ');

        if (names.Contains(input.text))
        {
            print("Instantiating " + input.text);
            var bug = Instantiate(bugPrefab);

            var bm = bug.GetComponentInChildren<BugManager>();
            bm.bugInfo = bg.LoadFromPP(input.text);
            bm.SetModelAndMat();

            bs.AddBug(bm);
        }
    }
}
