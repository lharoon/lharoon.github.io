using System.Collections.Generic;
using UnityEngine;

public enum PlayMode { SingleClip, Random, Sequential }

[RequireComponent(typeof(AudioSource))]
public class SFXPlayer : MonoBehaviour
{
    public List<AudioClip> sfx;

    public PlayMode playMode;

    private AudioSource audioSource;

    private int sfxIdx = 0;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
    }

    private void Start()
    {
        switch (playMode)
        {
            case PlayMode.SingleClip:
                if (sfx.Count > 0)
                    audioSource.clip = sfx[0];
                break;
            case PlayMode.Random:
                audioSource.clip = sfx[Random.Range(0, sfx.Count)];
                break;
            case PlayMode.Sequential:
                audioSource.clip = sfx[0];
                break;
            default:
                break;
        }
    }

    public void PlaySFX()
    {
        if (audioSource.isPlaying) return;

        switch (playMode)
        {
            //case PlayMode.SingleClip:
            //    break;
            case PlayMode.Random:
                audioSource.clip = sfx[Random.Range(0, sfx.Count)];
                break;
            case PlayMode.Sequential:
                audioSource.clip = sfxIdx < sfx.Count - 1 ? sfx[++sfxIdx] : sfx[0];
                break;
            default:
                break;
        }

        audioSource.Play();
    }
}
