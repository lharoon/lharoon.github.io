using UnityEngine;

public enum HoleSize { One, Two, Three, Four }

public class HoleInfo : MonoBehaviour
{
    [SerializeField]
    private HoleSize holeSize;

    public HoleSize HoleSize { get { return holeSize; } }
}
