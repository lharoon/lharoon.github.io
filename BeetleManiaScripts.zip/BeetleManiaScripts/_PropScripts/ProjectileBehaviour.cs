using UnityEngine;

public class ProjectileBehaviour : MonoBehaviour
{
    private Rigidbody rb;

    private const float speed = 5f, maxTimeToDie = 3f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Start()
    {
        Destroy(gameObject, maxTimeToDie);
    }

    public void Shoot(Vector3 targetPos)
    {
        rb.velocity = (targetPos - transform.position).normalized * speed;
    }

    private void OnCollisionEnter(Collision collision)
    {
        Destroy(gameObject);
    }
}
