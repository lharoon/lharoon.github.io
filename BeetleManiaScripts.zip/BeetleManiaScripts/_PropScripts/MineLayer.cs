using System.Collections.Generic;
using UnityEngine;

public class MineLayer : MonoBehaviour
{
    public List<Transform> mines;

    public Material mineMaterial;

    public int num = 4;

    public Transform minePrefab;

    private void Start()
    {
        for (int i = 0; i < mines.Count; i++)
        {
            if (i + 1 == mines.Count)
                InstantiateMines(mines[i], mines[0]);
            else
                InstantiateMines(mines[i], mines[i + 1]);
        }
    }

    private void InstantiateMines(Transform mine1, Transform mine2)
    {
        Vector3 dir = (mine2.position - mine1.position).normalized;
        float length = Mathf.Abs((mine2.position - mine1.position).magnitude);
        float distance = length / (num + 1);

        Vector3 newPos = mine1.position;

        for (int i = 0; i < num; i++)
        {
            newPos += dir * distance;
            var mine = Instantiate(minePrefab, newPos, Quaternion.identity);
            mine.parent = transform;
        }
    }
}
