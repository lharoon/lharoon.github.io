using DG.Tweening;
using System.Collections;
using UnityEngine;

public class LaunchpadBehaviour : MonoBehaviour
{
    private float launchForce = 500f;

    private float startingY;

    private bool isLaunching;

    private void Start()
    {
        startingY = transform.localScale.y;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("target") && !isLaunching)
        {
            StartCoroutine(Launch(other.GetComponent<Rigidbody>()));
        }
    }

    IEnumerator Launch(Rigidbody rb)
    {
        isLaunching = true;

        yield return new WaitForSeconds(0.2f);

        rb.GetComponent<Rigidbody>().AddForce((Vector3.up + rb.velocity.normalized) * launchForce);

        yield return new WaitForSeconds(0.05f);

        transform.DOScaleY(1, 1).SetEase(Ease.OutElastic).OnComplete(Recede);

        isLaunching = false;
    }

    private void Recede()
    {
        transform.DOScaleY(startingY, 1);
    }
}
