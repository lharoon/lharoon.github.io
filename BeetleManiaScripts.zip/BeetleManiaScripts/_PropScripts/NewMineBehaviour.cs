using System.Collections;
using BeetleMania;
using DG.Tweening;
using UnityEngine;

public class NewMineBehaviour : MonoBehaviour
{
    public float radius = 5.0F;
    public float power = 10.0F;

    [SerializeField]
    private MeshRenderer model;
    [SerializeField]
    private GameObject explosionFxPrefab;
    [SerializeField]
    private SFXPlayer sFX;

    private bool isActive;

    private void Start()
    {
        var am = FindObjectOfType<ArenasManager>();
        transform.parent = am.arenas[am.ActiveArenaIdx].transform;
    }

    public IEnumerator ActivateAfterT(float t)
    {
        yield return new WaitForSeconds(t);
        isActive = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (isActive &&
            (collision.gameObject.CompareTag("target") || collision.gameObject.CompareTag("obstacle")))
            Explode(collision.gameObject);
    }

    private void Explode(GameObject collisionObj)
    {
        sFX.PlaySFX();

        var bm = collisionObj.GetComponent<BugManager>();

        if (bm != null)
            bm.Kill();
        else
            Destroy(collisionObj);

        // AddExplosionForce
        Vector3 explosionPos = transform.position;
        Collider[] colliders = Physics.OverlapSphere(explosionPos, radius);
        foreach (Collider hit in colliders)
        {
            Rigidbody rb = hit.GetComponent<Rigidbody>();

            if (rb != null)
                rb.AddExplosionForce(power, explosionPos, radius, 3.0F);
        }

        // TODO: Fx size should be relative to explosion force
        var explosionFx = Instantiate(explosionFxPrefab, transform.position,
                Quaternion.identity);
        sFX.transform.parent = explosionFx.transform; // Parent sfx to fx so that it plays
        Destroy(explosionFx, 3f);

        model.transform.DOScale(Vector3.zero, 0.1f);

        Destroy(gameObject, 0.1f);
    }
}
