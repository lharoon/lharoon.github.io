using System.Collections;
using BeetleMania;
using DG.Tweening;
using UnityEngine;

public class GrenadeBehaviour : MonoBehaviour
{
    public float radius = 5.0F;
    public float power = 10.0F;

    [SerializeField]
    private Collider col;
    [SerializeField]
    private MeshRenderer model;
    [SerializeField]
    private GameObject explosionFxPrefab;
    [SerializeField]
    private SFXPlayer sFX;

    private void Start()
    {
        var am = FindObjectOfType<ArenasManager>();
        transform.parent = am.arenas[am.ActiveArenaIdx].transform;

        model.transform.localScale = Vector3.zero;
        model.transform.DOScale(1, 0.5f);

        StartCoroutine(ActivateAfterT(0.5f));
    }

    private IEnumerator ActivateAfterT(float t)
    {
        yield return new WaitForSeconds(t);
        col.enabled = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        Explode(collision.gameObject);
    }

    private void Explode(GameObject collisionObj)
    {
        sFX.PlaySFX();

        var bm = collisionObj.GetComponent<BugManager>();

        if (bm != null)
            bm.Kill();
        else if (collisionObj.CompareTag("target") || collisionObj.CompareTag("obstacle"))
            Destroy(collisionObj);

        // AddExplosionForce
        Vector3 explosionPos = transform.position;
        Collider[] colliders = Physics.OverlapSphere(explosionPos, radius);
        foreach (Collider hit in colliders)
        {
            Rigidbody rb = hit.GetComponent<Rigidbody>();

            if (rb != null)
                rb.AddExplosionForce(power, explosionPos, radius, 3.0F);
        }

        var explosionFx = Instantiate(explosionFxPrefab, transform.position,
                Quaternion.identity);
        sFX.transform.parent = explosionFx.transform; // Parent sfx to fx so that it plays
        Destroy(explosionFx, 3f);

        Destroy(gameObject);
    }
}
