using UnityEngine;

public class ExplosiveBoxBehaviour : MonoBehaviour
{
    public Transform explosionFxPrefab;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("target"))
        {
            if (collision.relativeVelocity.magnitude > 3f)
            {
                Vector3 pos = transform.position;
                pos.y -= 0.5f; // Foot of box

                var explosionFx = Instantiate(explosionFxPrefab, transform.position, Quaternion.identity);
                Destroy(explosionFx.gameObject, 3f);

                var bm = collision.gameObject.GetComponent<BugManager>();
                if (bm != null) bm.Kill();

                Destroy(gameObject);
            }
        }
    }
}
