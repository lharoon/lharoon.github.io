using DG.Tweening;
using System.Collections;
using UnityEngine;

public class MineBehaviour : MonoBehaviour
{
    public MeshRenderer model;

    public GameObject explosionFxPrefab;

    private Vector3 modelSize;

    private void Start()
    {
        modelSize = model.transform.localScale;
    }

    private void OnCollisionEnter(Collision collision)
    {
        // TODO: AddExplosionForce

        if (collision.gameObject.CompareTag("target"))
        {
            StartCoroutine("Explode");
        }
    }

    private IEnumerator Explode()
    {
        var explosionFx = Instantiate(explosionFxPrefab, transform.position,
                Quaternion.identity);
        Destroy(explosionFx, 3f);

        model.transform.DOScale(Vector3.zero, 0.1f);

        yield return new WaitForSeconds(1.5f);

        model.transform.DOScale(modelSize, 1f);
    }
}
