using UnityEngine;

public class TeleporterBehaviour : MonoBehaviour
{
    public Transform newPos;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("target"))
        {
            other.transform.position = newPos.position;
        }
    }
}
