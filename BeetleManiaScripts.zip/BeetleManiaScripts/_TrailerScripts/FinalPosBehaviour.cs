using UnityEngine;

public class FinalPosBehaviour : MonoBehaviour
{
    public bool HasReachedFinalPos { get; private set; }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("target"))
        {
            HasReachedFinalPos = true;
        }
    }
}
