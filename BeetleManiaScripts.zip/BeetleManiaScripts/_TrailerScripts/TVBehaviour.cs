using UnityEngine;

public class TVBehaviour : MonoBehaviour
{
    public Transform collisionFxPrefab;

    public bool HasCollidedWithTV { get; private set; }

    private bool onSpawn = true;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("target"))
        {
            HasCollidedWithTV = true;
        }

        if (collision.gameObject.CompareTag("floor") && !onSpawn)
        {
            var collisionFx = Instantiate(collisionFxPrefab, collision.GetContact(0).point, Quaternion.identity);
            Destroy(collisionFx.gameObject, 3f);
        }

        onSpawn = false;
    }
}
