using Cinemachine;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Video;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class TrailerManager : MonoBehaviour
{
    public CinemachineVirtualCamera virtualCamera;
    public VideoPlayer videoPlayer;
    public VideoClip beetleFightClip;

    public GameObject vid1, vid2;

    public float startFov = 20f, endFov = 40f;
    public float zoomTime = 10f;

    public BugManager starBug;
    public GameObject hiddenBugs; // TEMP
    public BugManager hiddenBug;

    public GameObject finalTarget;

    public FinalPosBehaviour finalPos;
    public TVBehaviour tv;

    public Material hiddenBugMat;

    public GameObject fgOutro, title, subtitle, comingSoonText;
    public List<GameObject> subtitles;
    public AudioSource jingle;

    private bool isAttackingTV, isRevealingBugs, isShowingSubtitle;

    private List<BugManager> bugManagers = new List<BugManager>();

    private void Awake()
    {
        // Configure bug attributes
        starBug.bugInfo.SetValue(AT.Courage, 3);
        starBug.bugInfo.SetValue(AT.Aggression, 3);

        foreach (var bm in hiddenBugs.GetComponentsInChildren<BugManager>())
        {
            bm.bugInfo.RandomiseAttributeValues();
            bm.bugInfo.SetValue(AT.Courage, 3);
            bm.bugInfo.SetValue(AT.Aggression, 3);
            bm.bugInfo.SetValue(AT.Speed, 3);
            bm.bmm.SetRandom();
            //bm.enabled = false;

            bugManagers.Add(bm);
        }

        hiddenBug.bugInfo.SetValue(AT.Courage, 3);
        hiddenBug.bugInfo.SetValue(AT.Aggression, 3);
        hiddenBug.bugInfo.SetValue(AT.Speed, 3);
        //hiddenBug.bmm.SetMaterial(hiddenBugMat); // Red
    }

    private void Start()
    {
        //virtualCamera.m_Lens.FieldOfView = 20;
        //DOTween.To(() => virtualCamera.m_Lens.FieldOfView, x => virtualCamera.m_Lens.FieldOfView = x, endFov, zoomTime);

        StartCoroutine("PlayBeetleFightClip");
    }

    private void Update()
    {
        if (finalPos.HasReachedFinalPos && !isAttackingTV)
        {
            StartCoroutine("AttackTV");
        }

        if (tv.HasCollidedWithTV && !isRevealingBugs)
        {
            StartCoroutine("RevealBugs");
        }

        if (!isShowingSubtitle && jingle.time >= 1.6f)
        {
            //subtitle.SetActive(true);
            StartCoroutine("ShowSubtitle");
        }
    }

    private IEnumerator PlayBeetleFightClip() // #1
    {
        yield return new WaitForSeconds(4f);

        vid1.SetActive(false);
        vid2.SetActive(true);

        starBug.SwitchState(BugState.Idle);
    }

    private IEnumerator AttackTV() // #2
    {
        isAttackingTV = true;

        //starBug.anim.PlayAlertAnimation();

        yield return new WaitForSeconds(1);

        starBug.anim.PlayAttackAnimation();

        yield return new WaitForSeconds(1.5f);

        starBug.anim.PlayWalkAnimation();

        starBug.SetTarget(vid2.transform);
        starBug.SwitchState(BugState.Attack);
    }

    private IEnumerator RevealBugs() // #3
    {
        isRevealingBugs = true;

        starBug.SwitchState(BugState.Null);
        starBug.anim.PlayIdleAnimation();

        yield return new WaitForSeconds(3);

        //hiddenBug.anim.PlayAlertAnimation();

        yield return new WaitForSeconds(1);

        starBug.anim.Rotate180();

        yield return new WaitForSeconds(1);

        hiddenBug.SetTarget(starBug.transform);
        hiddenBug.SwitchState(BugState.Attack);

        finalTarget.SetActive(true);
        starBug.SetTarget(finalTarget.transform);
        starBug.bugInfo.SetValue(AT.Speed, 3);
        starBug.SwitchState(BugState.Attack);

        yield return new WaitForSeconds(1.5f);

        vid2.GetComponent<VideoPlayer>().SetDirectAudioVolume(0, 0);

        jingle.gameObject.SetActive(true);
        fgOutro.SetActive(true);
        title.SetActive(true);

        //yield return new WaitForSeconds(1);

        //subtitle.SetActive(true);
    }

    private IEnumerator ShowSubtitle() // #4
    {
        isShowingSubtitle = true;
        subtitles[0].SetActive(true);
        yield return new WaitForSeconds(0.25f);
        subtitles[1].SetActive(true);
        yield return new WaitForSeconds(0.25f);
        subtitles[2].SetActive(true);

        yield return new WaitForSeconds(3);

        title.GetComponent<Image>().DOFade(0, 0.5f);
        foreach (var text in subtitles)
            text.GetComponent<TextMeshProUGUI>().DOFade(0, 0.5f);
        comingSoonText.SetActive(true);
    }
}
