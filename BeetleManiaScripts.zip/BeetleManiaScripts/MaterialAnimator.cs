using System.Collections.Generic;
using UnityEngine;

public class MaterialAnimator : MonoBehaviour
{
    public List<Material> materials;

    private SkinnedMeshRenderer meshRenderer;

    private int matIdx = 0;

    private void Awake()
    {
        meshRenderer = GetComponent<SkinnedMeshRenderer>();
    }

    private void Start()
    {
        if (materials.Count > 1)
            InvokeRepeating("ChangeMaterial", 0, 0.5f);
    }

    private void ChangeMaterial()
    {
        if (matIdx == materials.Count)
            matIdx = 0;
        meshRenderer.material = materials[matIdx++];
    }
}
