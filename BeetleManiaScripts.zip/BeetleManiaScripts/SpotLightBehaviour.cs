using UnityEngine;

public class SpotLightBehaviour : MonoBehaviour
{
    private Light light;

    private BugSelector bugSelector;

    private void Start()
    {
        light = GetComponent<Light>();
        bugSelector = FindObjectOfType<BugSelector>();
    }

    private void Update()
    {
        if (bugSelector.SelectedBug == null || bugSelector.SelectedBug.IsDead)
        {
            light.enabled = false;
        }
        else
        {
            Vector3 newPos = bugSelector.SelectedBug.transform.position;
            newPos.y = transform.position.y;
            transform.position = newPos;
            light.enabled = true;
        }
    }
}
