using UnityEngine;
using UnityEngine.SceneManagement;

public class BackButtons : MonoBehaviour
{
    public void LoadPreviousScene()
    {
        string previousScene = GameInfo.previousScene;
        GameInfo.previousScene = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(previousScene);
    }

    public void LoadTitleScreen()
    {
        SceneManager.LoadScene(GameInfo.titleScreenName);
    }
}
