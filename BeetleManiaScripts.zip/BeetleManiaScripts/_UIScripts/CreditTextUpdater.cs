using TMPro;
using UnityEngine;

public class CreditTextUpdater : MonoBehaviour
{
    private TextMeshProUGUI creditText;

    private void Awake()
    {
        creditText = GetComponent<TextMeshProUGUI>();
    }

    private void Update()
    {
        creditText.text = GameInfo.credit.ToString();
    }
}
