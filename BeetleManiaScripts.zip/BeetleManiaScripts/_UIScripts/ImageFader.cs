using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public enum FadeType { None, FadeIn, FadeOut }

public class ImageFader : MonoBehaviour
{
    public FadeType fadeOnStart;
    public float fadeInDuration = 0.5f, fadeOutDuration = 0.5f;

    private Image image;

    private void Start()
    {
        image = GetComponent<Image>();

        image.enabled = true;

        if (fadeOnStart == FadeType.FadeIn)
            FadeIn();
        else if (fadeOnStart == FadeType.FadeOut)
            FadeOut();
    }

    public void FadeIn()
    {
        gameObject.SetActive(true);
        image.DOFade(1, fadeOutDuration);
    }

    public void FadeOut()
    {
        image.DOFade(0, fadeOutDuration);
        StartCoroutine(ObjUtils.SetActiveAfterT(gameObject, false, fadeOutDuration));
    }
}
