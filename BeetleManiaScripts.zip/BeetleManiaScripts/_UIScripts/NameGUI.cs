using TMPro;
using UnityEngine;

public class NameGUI : MonoBehaviour
{
    public TextMeshProUGUI nameValue;

    private BugSelector bugSelector;
    private BugManager selectedBug;

    private void Start()
    {
        bugSelector = FindObjectOfType<BugSelector>();
    }

    private void Update()
    {
        if (bugSelector.SelectedBug == null) return;

        if (selectedBug != bugSelector.SelectedBug)
        {
            selectedBug = bugSelector.SelectedBug;
            nameValue.text = selectedBug.bugInfo.bugName;
        }
    }
}
