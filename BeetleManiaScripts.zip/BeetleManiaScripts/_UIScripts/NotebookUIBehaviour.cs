using TMPro;
using UnityEngine;

public class NotebookUIBehaviour : MonoBehaviour
{
    public TextMeshProUGUI notebookLabel;
    public TMP_InputField inputField;

    private BugSelector bugSelector;

    private BugManager selectedBug;
    private bool isFirstTime;

    private void Start()
    {
        bugSelector = FindObjectOfType<BugSelector>();
    }

    private void Update()
    {
        if (selectedBug != bugSelector.SelectedBug)
        {
            isFirstTime = true;
            selectedBug = bugSelector.SelectedBug;
        }

        if (bugSelector.SelectedBug == null) return;

        notebookLabel.text = GetNotebookLabel(bugSelector.SelectedBug.bugInfo.bugName);

        if (isFirstTime)
        {
            isFirstTime = false;
            inputField.text = selectedBug.bugInfo.notes;
        }
        else
        {
            selectedBug.bugInfo.notes = inputField.text; // Save local copy every frame (could use on value changed instead)
        }
    }

    private string GetNotebookLabel(string bugName)
    {
        return "Notes on " + bugName;
    }

    public void SaveNotes()
    {
        PlayerPrefs.SetString(selectedBug.bugInfo.bugName, inputField.text);
    }
}
