using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ChatTextInfo : MonoBehaviour
{
    public Image bg;
    public TextMeshProUGUI text;

    public Sprite sprite;
    public string textStr;

    private void Awake()
    {
        Vector3 startingScale = transform.localScale;
        startingScale.x = 0;
        transform.localScale = startingScale;
    }

    private void Start()
    {
        //Color transparent = bg.color;
        //transparent.a = 0;
        //bg.color = transparent;
        //bg.sprite = sprite;
        //text.text = textStr;
    }
}
