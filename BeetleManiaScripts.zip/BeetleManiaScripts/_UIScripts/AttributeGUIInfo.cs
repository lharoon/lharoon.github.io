using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AttributeGUIInfo : MonoBehaviour
{
    public TextMeshProUGUI statName;
    public Slider statValue;
    public Image statCurrentValue;

    public AT atr;

    private BugSelector bugSelector;

    private BugManager selectedBug;
    private bool isFirstTime;

    private void Start()
    {
        bugSelector = FindObjectOfType<BugSelector>();
    }

    private void Update()
    {
        if (selectedBug != bugSelector.SelectedBug)
        {
            isFirstTime = true;
            selectedBug = bugSelector.SelectedBug;
        }

        if (bugSelector.SelectedBug == null) return;

        if (isFirstTime)
        {
            isFirstTime = false;
            statName.text = selectedBug.bugInfo.GetAtr(atr).guiName;
            statValue.value = selectedBug.bugInfo.GetValue(atr);
        }
        else
        {
            selectedBug.bugInfo.attributes[(int)atr].value = (int)statValue.value;
            //selectedBug.bugInfo.attributes[(int)atr].CurrentValue = statValue.value;
        }
    }

    public void ResetValues()
    {
        isFirstTime = true;
    }
}
