using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

namespace BeetleMania
{
    public class CurtainBehaviour : MonoBehaviour
    {
        // Inspector fields

        // Local components
        private Image image;
        private Animator animator;
        private AudioSource audioSource;

        // Flags
        private bool hasAnimationCompleted;

        private void Awake()
        {
            image = GetComponent<Image>();
            animator = GetComponent<Animator>();
            audioSource = GetComponent<AudioSource>();
        }

        private void Start()
        {
            if (!CompareTag("exit-transition"))
                EnableTransition();
        }

        private void Update()
        {
            if (!CompareTag("exit-transition"))
            {
                // Has completed animation
                if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime > 1f && !hasAnimationCompleted)
                {
                    hasAnimationCompleted = true;
                    image.DOFade(0f, 0.5f);
                    StartCoroutine(ObjUtils.SetActiveAfterT(image.gameObject, false, 0.5f));
                }
            }
        }

        public void EnableTransition()
        {
            image.enabled = true;
            animator.enabled = true;
            audioSource.enabled = true;
        }
    }
}
