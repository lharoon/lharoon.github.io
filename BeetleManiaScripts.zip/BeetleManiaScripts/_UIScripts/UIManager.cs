using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public List<TextMeshProUGUI> defaultTexts;
    public AttributeGUIInfo attributeGUIPrefab;
    public Transform stats;
    public RectTransform statsUI, notebookUI;
    public TextMeshProUGUI notebookLabel;
    public float gap;

    public BugManager bug;

    public RectTransform leftTestUI, rightTestUI;
    public RectTransform restartButton, timeScaleButtons;
    public CanvasGroup debugPanel;
    #endregion

    private BugSelector bugSelector;
    private Vector3 currentPos = Vector3.zero;

    private bool isUIShown;

    private void Start()
    {
        bugSelector = GetComponent<BugSelector>();

        if (bug == null)
        {
            print("Set bug from inspector!");
            return;
        }

        for (int i = 0; i < bug.bugInfo.attributes.Count; i++)
        {
            Vector3 newPos = currentPos;
            newPos.y -= gap;
            currentPos = newPos;

            var atrGui = Instantiate(attributeGUIPrefab, stats);
            atrGui.GetComponent<RectTransform>().anchoredPosition = currentPos;

            atrGui.atr = (AT)i;
        }
    }

    private void Update()
    {
        // Show
        if (bugSelector.SelectedBug != null && !isUIShown)
        {
            FadeDefaultTexts(false);
            statsUI.DOAnchorPosX(10, 0.5f);
            notebookUI.DOAnchorPosX(-10, 0.5f);
            isUIShown = true;

            leftTestUI.DOAnchorPosX(-250, 0.5f);
            rightTestUI.DOAnchorPosX(250, 0.5f);
            //restartButton.DOAnchorPosX(250, 0.5f);
            timeScaleButtons.DOAnchorPosX(250, 0.5f);

            debugPanel.DOFade(0, 0.5f);
            debugPanel.gameObject.SetActive(false);
        }
        // Hide
        else if (bugSelector.SelectedBug == null && isUIShown)
        {
            FadeDefaultTexts(true);
            statsUI.DOAnchorPosX(-250, 0.5f);
            notebookUI.DOAnchorPosX(250, 0.5f);
            isUIShown = false;

            leftTestUI.DOAnchorPosX(0, 0.5f);
            rightTestUI.DOAnchorPosX(0, 0.5f);
            //restartButton.DOAnchorPosX(-10, 0.5f);
            timeScaleButtons.DOAnchorPosX(-10, 0.5f);

            debugPanel.DOFade(1, 0.5f);
            debugPanel.gameObject.SetActive(true);
        }
    }

    private void FadeDefaultTexts(bool isShow)
    {
        float tgt = isShow ? 1 : 0;

        foreach (var text in defaultTexts)
        {
            text.DOFade(tgt, 0.5f);
        }
    }

    public void RandomiseAttributeValues()
    {
        bugSelector.SelectedBug.RandomiseAttributeValues();
        RefreshAttributeUI();
    }

    public void MaximiseAttributeValues()
    {
        bugSelector.SelectedBug.MaximiseAttributeValues();
        RefreshAttributeUI();
    }

    public void MinimiseAttributeValues()
    {
        bugSelector.SelectedBug.MinimiseAttributeValues();
        RefreshAttributeUI();
    }

    private void RefreshAttributeUI()
    {
        foreach (var info in FindObjectsOfType<AttributeGUIInfo>())
            info.ResetValues();
    }
}
