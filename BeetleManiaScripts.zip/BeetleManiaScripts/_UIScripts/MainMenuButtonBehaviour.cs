using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class MainMenuButtonBehaviour : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler // TEMP
{
    public string buttonName, commentStr;

    public TextMeshProUGUI buttonText, commentText;
    public RectTransform comment;

    private void Start()
    {
        buttonText.text = buttonName;
        commentText.text = commentStr;

        comment.localScale = new Vector3(0, 0, 1);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        comment.localScale = new Vector3(0, 1, 1);
        comment.DOScaleX(1, 0.5f).SetEase(Ease.OutBack);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        comment.DOScaleY(0, 0.25f);
    }
}
