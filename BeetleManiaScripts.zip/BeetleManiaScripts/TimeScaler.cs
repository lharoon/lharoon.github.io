using TMPro;
using UnityEngine;

public enum TimeScale { One, Two, Four }

public class TimeScaler : MonoBehaviour
{
    public TextMeshProUGUI timeScaleText;

    private TimeScale timeScale;

    public void IncrementTimeScale()
    {
        if ((int)timeScale + 1 < 3)
            timeScale++;
        else
            timeScale = TimeScale.One;

        UpdateTimeScale();
    }

    public void DecrementTimeScale()
    {
        if ((int)timeScale > 0)
            timeScale--;
        else
            timeScale = TimeScale.Four;

        UpdateTimeScale();
    }

    private void UpdateTimeScale()
    {
        switch (timeScale)
        {
            case TimeScale.One:
                Time.timeScale = 1;
                timeScaleText.text = "x1";
                break;
            case TimeScale.Two:
                Time.timeScale = 2;
                timeScaleText.text = "x2";
                break;
            case TimeScale.Four:
                Time.timeScale = 4;
                timeScaleText.text = "x4";
                break;
            default:
                break;
        }
    }
}
