using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GameUtils
{
    public static class SceneUtils
    {
        public static IEnumerator LoadSceneAfterT(string sceneName, float t)
        {
            Time.timeScale = 1; // Reset time scale
            yield return new WaitForSeconds(t);
            SceneManager.LoadScene(sceneName);
        }

        public static IEnumerator LoadSceneWithTransition(string sceneName)
        {
            Time.timeScale = 1; // Reset time scale

            // Start transition
            var exitTransition = GameObject.FindGameObjectWithTag("exit-transition").GetComponent<BeetleMania.CurtainBehaviour>();
            exitTransition.EnableTransition();

            // Wait until transition completes
            var animator = exitTransition.GetComponent<Animator>();
            yield return new WaitForSeconds(animator.GetCurrentAnimatorStateInfo(0).length);

            SceneManager.LoadScene(sceneName);
        }
    }
}
