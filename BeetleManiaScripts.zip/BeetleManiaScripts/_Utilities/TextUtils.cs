using System.Collections;
using TMPro;

public static class TextUtils
{
    public static IEnumerator LerpNumericText(TextMeshProUGUI text, int currentValue, int targetValue)
    {
        while (currentValue < targetValue)
        {
            currentValue++; // TODO: Increment over time
            text.text = currentValue.ToString();
            yield return null;
        }
    }
}
