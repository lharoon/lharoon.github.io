using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneLoader
{
    public static void LoadScene(string newSceneName)
    {
        GameInfo.previousScene = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(newSceneName);
    }

    public static IEnumerator LoadSceneAfterT(string newSceneName, float t)
    {
        yield return new WaitForSeconds(t);
        LoadScene(newSceneName);
    }
}
