﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Game object utilities
/// </summary>
public static class ObjUtils
{
    /// <summary>
    /// Finds nearest object among objects (array)
    /// </summary>
    /// <param name="objs"></param>
    /// <param name="pos"></param>
    /// <returns></returns>
    public static GameObject GetNearestObject(GameObject[] objs, Vector3 pos,
        List<GameObject> excludes = null)
    {
        GameObject nearestObj = null;
        var minDistance = Mathf.Infinity;

        foreach (GameObject obj in objs)
        {
            if (excludes != null)
            {
                if (excludes.Contains(obj))
                    continue;
            }

            var distance = Vector3.Distance(obj.transform.position, pos);

            if (distance < minDistance)
            {
                nearestObj = obj;
                minDistance = distance;
            }
        }
        return nearestObj;
    }

    /// <summary>
    /// Finds nearest object among objects (array)
    /// </summary>
    /// <param name="objs"></param>
    /// <param name="pos"></param>
    /// <returns></returns>
    public static GameObject GetNearestObjectInLineOfSight(GameObject[] objs, Vector3 pos,
        List<GameObject> excludes = null, float minDistance = 0, int layer = -1)
    {
        GameObject nearestObj = null;
        var distanceOfNearestObj = Mathf.Infinity;

        foreach (GameObject obj in objs)
        {
            if (excludes != null)
            {
                if (excludes.Contains(obj))
                    continue;
            }

            var distance = Vector3.Distance(obj.transform.position, pos);

            //if (distance < minDistance) continue;

            LayerMask layerMask;

            if (layer < 0)
                layerMask = Physics.DefaultRaycastLayers;
            else
                layerMask = ~(1 << LayerMask.NameToLayer("Ignore Raycast") | 1 << layer);
            //

            if (distance < distanceOfNearestObj)
            {
                //if (Physics.Linecast(pos, obj.transform.position,
                //    Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
                //    continue;
                if (Physics.Linecast(pos, obj.transform.position,
                    layerMask, QueryTriggerInteraction.Ignore))
                    continue;

                nearestObj = obj;
                distanceOfNearestObj = distance;
            }
        }
        return nearestObj;
    }

    /// <summary>
    /// Finds nearest object among objects (list)
    /// </summary>
    /// <param name="objs"></param>
    /// <param name="pos"></param>
    /// <returns></returns>
    public static GameObject GetNearestObject(List<GameObject> objs, Vector3 pos)
    {
        GameObject nearestObj = null;
        var minDistance = Mathf.Infinity;

        foreach (GameObject obj in objs)
        {
            var distance = Vector3.Distance(obj.transform.position, pos);

            if (distance < minDistance)
            {
                nearestObj = obj;
                minDistance = distance;
            }
        }
        return nearestObj;
    }

    public static GameObject GetNearestObject(string tag, Vector3 pos, int layer = -1)
    {
        var objs = GameObject.FindGameObjectsWithTag(tag);
        //var nearestObj = GetNearestObject(objs, pos);
        var nearestObj = GetNearestObjectInLineOfSight(objs, pos, minDistance: 2f, layer: layer);
        return nearestObj;
    }

    public static IEnumerator SetActiveAfterT(GameObject go, bool isActive, float t)
    {
        yield return new WaitForSeconds(t);
        go.SetActive(isActive);
    }
}
