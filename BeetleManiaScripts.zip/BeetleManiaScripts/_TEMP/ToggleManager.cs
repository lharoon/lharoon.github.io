using UnityEngine;
using UnityEngine.UI;

public class ToggleManager : MonoBehaviour
{
    public Toggle dynamicBoneToggle, headRigToggle;

    private void Update()
    {
        var bugs = FindObjectsOfType<BugManager>();

        foreach (var bug in bugs)
        {
            bug.isDynamicBoneOn = dynamicBoneToggle.isOn;
            bug.isHeadRigOn = headRigToggle.isOn;
        }
    }
}
