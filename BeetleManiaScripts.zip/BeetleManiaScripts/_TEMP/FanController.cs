using UnityEngine;

public class FanController : MonoBehaviour
{
    public BugManager bm;

    public float rotSpeed = 100f;

    private void Start()
    {
        bm.RandomiseAttributeValues();
    }

    private void Update()
    {
        transform.position = bm.transform.position;

        transform.Rotate(transform.rotation.eulerAngles.x, rotSpeed * Time.deltaTime,
            transform.rotation.eulerAngles.z);
    }
}
