using UnityEngine;

public class PlacerGenerator : MonoBehaviour
{
    public GameObject placerPrefab;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
            SelectOnMouseDown();
    }

    private void SelectOnMouseDown()
    {
        // http://answers.unity.com/answers/787227/view.html
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.name == name)
                Instantiate(placerPrefab);
        }
    }
}
