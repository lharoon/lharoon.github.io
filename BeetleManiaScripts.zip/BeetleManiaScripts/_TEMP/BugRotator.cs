using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BugRotator : MonoBehaviour // TEMP
{
    public BugManager bm;

    private void Start()
    {
        if (bm.bugInfo.hasLost)
        {
            var rot = transform.rotation.eulerAngles;
            rot.z = 180;
            transform.rotation = Quaternion.Euler(rot);
        }
    }
}
