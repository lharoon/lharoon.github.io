using System;
using System.Collections.Generic;
using UnityEngine;

//[Serializable]
//public enum PValue
//{
//    One,
//    Two,
//    Three,
//    Four
//}

[Serializable]
public enum AT
{
    Speed,
    Range,
    Stealth,
    Courage,
    Aggression,
    Stamina,
    Buoyancy
    //Strength,
}

[Serializable]
public class Attribute
{
    public string guiName;
    public int value;

    //public float CurrentValue { get; set; }

    public Attribute(string guiName, int value = 0)
    {
        this.guiName = guiName;
        this.value = value;

        //CurrentValue = value;
    }
}

[Serializable]
public enum BeetleType
{
    Rhinoceros,
    Stag,
    Hercules
}

//[Serializable]
public class BugInfo
{
    public Guid guid;

    public string bugName, university, favouriteSandwich;

    public List<Attribute> attributes = new List<Attribute>()
    {
        new Attribute("speed"),
        new Attribute("range"),
        new Attribute("stealth"),
        new Attribute("courage"),
        new Attribute("aggression"),
        new Attribute("stamina"),
        new Attribute("buoyancy")
        //new Attribute("strength"),
    };

    public float staminaIncrement = 0; // TEMP

    public BeetleType beetleType;

    public int hatIdx;

    public List<Tuple<AbilityType, int>> abilities = new List<Tuple<AbilityType, int>>();

    public string notes;

    public int modelIdx, materialIdx, hatMaterialIdx;

    public Material material, hatMaterial;

    public int numLives = 1;

    public int layer = 0;

    // Tournament related info (TODO: Encapsulate)
    public bool hasLost;
    public bool isSemis, isFinals, isChampion, isMatch;
    public RoundLevel roundLevel;

    private const int maxNumOfDifferentAbilities = 2, maxGemCount = 4;

    public Attribute GetAtr(AT atr)
    {
        return attributes[(int)atr];
    }

    public int GetValue(AT atr)
    {
        return attributes[(int)atr].value;
    }

    public void SetValue(AT atr, int value)
    {
        attributes[(int)atr].value = value;
    }

    //public float GetCurrentValue(AT atr)
    //{
    //    return attributes[(int)atr].CurrentValue;
    //}

    //public void SetCurrentValue(AT atr, float value)
    //{
    //    attributes[(int)atr].CurrentValue = value;
    //}

    //public void ResetCurrentValue(AT atr)
    //{
    //    attributes[(int)atr].CurrentValue = attributes[(int)atr].value;
    //}

    //public void AddToCV(AT atr, float value)
    //{
    //    attributes[(int)atr].CurrentValue += value;
    //}

    //public void SubtractFromCV(AT atr, float value)
    //{
    //    attributes[(int)atr].CurrentValue -= value;
    //}

    //public bool IsCVLessThanV(AT atr)
    //{
    //    return attributes[(int)atr].CurrentValue < attributes[(int)atr].value;
    //}

    //public float GetRatio(AT atr)
    //{
    //    return attributes[(int)atr].CurrentValue / attributes[(int)atr].value;
    //}

    public void RandomiseAttributeValues()
    {
        foreach (var atr in attributes)
            atr.value = UnityEngine.Random.Range(GameInfo.minAtrVal, GameInfo.maxAtrVal + 1);

        staminaIncrement = UnityEngine.Random.Range(0, 0.49f); // TEMP
    }

    public void RandomiseAbilities()
    {
        var abilityTypes = Enum.GetValues(typeof(AbilityType));

        int numOfDifferentAbilities = UnityEngine.Random.Range(0,
            maxNumOfDifferentAbilities + 1); // 0 to 2

        int gemIdx = UnityEngine.Random.Range(0, maxGemCount);
        List<int> assignedIndices = new List<int>();

        #region Set abilities
        //if (numOfDifferentAbilities == 1)
        //{
        //    int abilityIdx = UnityEngine.Random.Range(0, abilityTypes.Length);
        //    int gemCount = UnityEngine.Random.Range(1, maxGemCount + 1);

        //    for (int i = 0; i < gemCount; i++)
        //    {
        //        //abilities.Add((AbilityType)abilityTypes.GetValue(abilityIdx));

        //        while (assignedIndices.Contains(gemIdx))
        //            gemIdx = UnityEngine.Random.Range(0, maxGemCount);
        //        assignedIndices.Add(gemIdx);

        //        abilities.Add(new Tuple<AbilityType, int>((AbilityType)abilityTypes.GetValue(abilityIdx), gemIdx));
        //    }
        //}
        //else if (numOfDifferentAbilities == 2)
        //{
        //    for (int i = 0; i < 2; i++)
        //    {
        //        int abilityIdx = UnityEngine.Random.Range(0, abilityTypes.Length);
        //        int gemCount = UnityEngine.Random.Range(1, 2);

        //        for (int j = 0; j < gemCount; j++)
        //        {
        //            //abilities.Add((AbilityType)abilityTypes.GetValue(abilityIdx));

        //            while (assignedIndices.Contains(gemIdx))
        //                gemIdx = UnityEngine.Random.Range(0, maxGemCount);
        //            assignedIndices.Add(gemIdx);

        //            abilities.Add(new Tuple<AbilityType, int>((AbilityType)abilityTypes.GetValue(abilityIdx), gemIdx));
        //        }
        //    }
        //}

        int abilityIdx = UnityEngine.Random.Range(0, abilityTypes.Length);
        int gemCount = UnityEngine.Random.Range(0, maxGemCount + 1);

        for (int i = 0; i < gemCount; i++)
        {
            while (assignedIndices.Contains(gemIdx))
                gemIdx = UnityEngine.Random.Range(0, maxGemCount);
            assignedIndices.Add(gemIdx);

            abilities.Add(new Tuple<AbilityType, int>((AbilityType)abilityTypes.GetValue(abilityIdx), gemIdx));
        }
        #endregion

        //for (int i = 0; i < maxGemCount; i++) // TEMP
        //    abilities.Add(new Tuple<AbilityType, int>(AbilityType.DodgeAndStrike, i));
    }

    public void RandomiseBeetleType()
    {
        beetleType = (BeetleType)UnityEngine.Random.Range(0, 3);

        // TODO: Move
        const int numOfHats = 90;
        hatIdx = UnityEngine.Random.Range(0, numOfHats);
    }
}
