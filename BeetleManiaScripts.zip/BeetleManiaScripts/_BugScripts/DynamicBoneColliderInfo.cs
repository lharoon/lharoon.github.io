using UnityEngine;

public class DynamicBoneColliderInfo : MonoBehaviour
{
    public BugManager bm;
}
