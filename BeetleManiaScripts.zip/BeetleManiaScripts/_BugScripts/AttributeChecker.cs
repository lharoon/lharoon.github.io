using UnityEngine;

public class AttributeChecker : MonoBehaviour
{
    private BugManager man;

    private void Awake()
    {
        man = GetComponent<BugManager>();
    }

    public float GetRange()
    {
        return man.bugInfo.GetValue(AT.Range) switch
        {
            0 => 2f * 2,
            1 => 3f * 2,
            2 => 4f * 2,
            _ => 5f * 2,
        };
    }

    public float GetSpeed()
    {
        //if (man.isBox)
        //{
        //    return man.bugInfo.GetValue(AT.Speed) switch
        //    {
        //        0 => 2.5f * 2,
        //        1 => 5f * 2,
        //        2 => 7.5f * 2,
        //        _ => 10f * 2,
        //    };
        //}

        return man.bugInfo.GetValue(AT.Speed) switch
        {
            0 => 2.5f,
            1 => 5f,
            2 => 7.5f,
            _ => 10f,
        };
    }

    public float GetStamina()
    {
        return man.bugInfo.GetValue(AT.Stamina) switch
        {
            0 => 1f + man.bugInfo.staminaIncrement,
            1 => 1.5f + man.bugInfo.staminaIncrement,
            2 => 2f + man.bugInfo.staminaIncrement,
            _ => 2.5f + man.bugInfo.staminaIncrement,
        };
    }

    public float GetSize()
    {
        return man.bugInfo.GetValue(AT.Speed) switch
        {
            0 => 1.125f,
            1 => 1f,
            2 => 0.875f,
            _ => 0.75f,
        };
    }

    private int GetSizeAsInt()
    {
        return man.bugInfo.GetValue(AT.Speed) switch
        {
            0 => 3,
            1 => 2,
            2 => 1,
            _ => 0,
        };
    }

    public bool CourageCheck()
    {
        return man.bugInfo.GetValue(AT.Courage) switch
        {
            //0 => false,
            0 => Random.value > 0.25f,
            1 => Random.value > 0.15f,
            _ => true,
        };
    }

    public bool SpotCheck(int stealthTgt)
    {
        return stealthTgt switch
        {
            0 => Random.value <= 0.5f,
            1 => Random.value <= 0.25f,
            2 => Random.value <= 0.15f,
            _ => Random.value <= 0.05f,
        };
    }

    public bool AggressionCheck()
    {
        return man.bugInfo.GetValue(AT.Aggression) switch
        {
            //0 => false,
            //1 => Random.value <= 0.05f,
            //2 => Random.value <= 0.15f,
            //_ => Random.value <= 0.5f,
            0 => Random.value <= 0.05f,
            1 => Random.value <= 0.15f,
            2 => Random.value <= 0.25f,
            _ => Random.value <= 0.5f,
        };
    }

    public bool FloatCheck()
    {
        return man.bugInfo.GetValue(AT.Buoyancy) switch
        {
            0 => Random.value <= 0.5f,
            1 => Random.value <= 0.75f,
            2 => Random.value <= 0.85f,
            _ => Random.value <= 0.95f,
            //0 => Random.value <= 0.5f,
            //1 => Random.value <= 0.25f,
            //2 => Random.value <= 0.15f,
            //_ => Random.value <= 0.05f,
        };
    }

    public bool PassOverHoleCheck(HoleSize holeSize)
    {
        return holeSize switch
        {
            HoleSize.One => GetSizeAsInt() > 0,
            HoleSize.Two => GetSizeAsInt() > 1,
            HoleSize.Three => GetSizeAsInt() > 2,
            _ => false,
        };
    }

    public bool CoinToss()
    {
        return Random.value > 0.5f;
    }
}
