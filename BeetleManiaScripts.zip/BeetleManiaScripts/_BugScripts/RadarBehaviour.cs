using UnityEngine;

public class RadarBehaviour : MonoBehaviour
{
    private void Update()
    {
        float x = 1 / transform.parent.localScale.x;
        transform.localScale = new Vector3(x, x, x);
    }
}
