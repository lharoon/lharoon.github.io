using System.Collections.Generic;
using UnityEngine;

public enum BugSfx { Footstep, Collision, Ability, Teleport, Fall, Fire, Splash }

public class BugSfxManager : MonoBehaviour
{
    public List<SFXPlayer> sounds;

    public void PlaySfx(BugSfx sfx) // TODO: Instantiate sfx prefab
    {
        sounds[(int)sfx].PlaySFX();
    }
}
