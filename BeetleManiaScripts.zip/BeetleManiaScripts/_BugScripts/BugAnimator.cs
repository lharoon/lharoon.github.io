using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Animations.Rigging;

public enum BugFX { BugCollision, RingOut, WaterCollision, BugDeath, DeathBySpikes, Ability, Dodge }

public class BugAnimator : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public BugManager man;

    public List<GameObject> bugFxPrefabs;

    public Animator animator;
    public Rig headRig;
    public GameObject smokeTrail;

    public Transform alertGraphic;
    #endregion

    #region Dynamic Bones
    public List<DynamicBoneCollider> DynamicBoneColliders { get; private set; } = new List<DynamicBoneCollider>();
    public List<DynamicBonePlaneCollider> DynamicBonePlaneColliders { get; private set; } = new List<DynamicBonePlaneCollider>();

    private List<DynamicBone> dynamicBones = new List<DynamicBone>();
    private DynamicBone neckBone;

    private List<GameObject> targets = new List<GameObject>();
    private List<GameObject> obstacles = new List<GameObject>();
    #endregion

    public Tween WaterBobbingAnimation { get; set; }

    private const float turningSpeed = 250f;

    // Flags
    private bool pauseMainAnim;
    private bool isWalking;

    private void Awake()
    {
        foreach (var collider in GetComponentsInChildren<DynamicBoneCollider>())
            DynamicBoneColliders.Add(collider);

        foreach (var collider in GetComponentsInChildren<DynamicBonePlaneCollider>())
            DynamicBonePlaneColliders.Add(collider);

        foreach (var bone in GetComponentsInChildren<DynamicBone>())
        {
            dynamicBones.Add(bone);
            if (bone.m_Root.name == "Neck") neckBone = bone;
        }
    }

    private void Start()
    {
        foreach (var target in GameObject.FindGameObjectsWithTag("target"))
        {
            if (target != man.gameObject) // Ignore self
                AddDynamicBoneColliders(target);
            targets.Add(target);
        }

        foreach (var obstacle in GameObject.FindGameObjectsWithTag("obstacle"))
        {
            AddDynamicBoneColliders(obstacle);
            obstacles.Add(obstacle);
        }
    }

    private void Update()
    {
        if (!man.IsDead)
        {
            SetPosition();
            if (!pauseMainAnim)
                SetRotation();
        }

        if (man.IsInanimate || man.bugInfo.hasLost)
            animator.speed = 0;
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Armature|walk") && isWalking)
            animator.speed = man.rb.velocity.magnitude / 2f;
        else
            DOTween.To(() => animator.speed, x => animator.speed = x, 1, 2);

        //smokeTrail.SetActive(man.rb.velocity.magnitude > 5f);

        //ActivateDynamicBone(man.isDynamicBoneOn);
        if (headRig != null)
            ActivateHeadRig(man.isHeadRigOn);

        UpdateDynamicBoneColliders();
    }

    private void UpdateDynamicBoneColliders()
    {
        if (GameObject.FindGameObjectsWithTag("target").Length != targets.Count)
        {
            foreach (var target in GameObject.FindGameObjectsWithTag("target"))
            {
                if (!targets.Contains(target))
                {
                    AddDynamicBoneColliders(target);
                    targets.Add(target);
                }
            }
        }

        if (GameObject.FindGameObjectsWithTag("obstacle").Length != obstacles.Count)
        {
            foreach (var obstacle in GameObject.FindGameObjectsWithTag("obstacle"))
            {
                if (!obstacles.Contains(obstacle))
                {
                    AddDynamicBoneColliders(obstacle);
                    obstacles.Add(obstacle);
                }
            }
        }

        // Remove null objects
        targets.RemoveAll(item => item == null);
        obstacles.RemoveAll(item => item == null);
    }

    private void AddDynamicBoneColliders(GameObject target)
    {
        var targetMan = target.GetComponent<BugManager>();

        if (targetMan != null)
        {
            foreach (var bone in dynamicBones)
            {
                foreach (var collider in targetMan.anim.DynamicBoneColliders)
                {
                    if (!bone.m_Colliders.Contains(collider))
                        bone.m_Colliders.Add(collider);
                }

                foreach (var collider in targetMan.anim.DynamicBonePlaneColliders)
                {
                    if (!bone.m_Colliders.Contains(collider))
                        bone.m_Colliders.Add(collider);
                }
            }
        }
        else // TEMP
        {
            foreach (var bone in dynamicBones)
            {
                foreach (var collider in target.GetComponentsInChildren<DynamicBoneCollider>())
                {
                    if (!bone.m_Colliders.Contains(collider))
                        bone.m_Colliders.Add(collider);
                }

                foreach (var collider in target.GetComponentsInChildren<DynamicBonePlaneCollider>())
                {
                    if (!bone.m_Colliders.Contains(collider))
                        bone.m_Colliders.Add(collider);
                }
            }
        }
    }

    public void SetPosition()
    {
        Vector3 newPos = man.transform.position;
        if (man.isBox) newPos.y = 0;
        transform.position = newPos;
    }

    private void SetRotation()
    {
        switch (man.BugState)
        {
            case BugState.Idle:
            case BugState.Retreat:
                transform.DOLookAt(transform.position + man.GetComponent<Rigidbody>().velocity, 0.5f, AxisConstraint.Y);
                Vector3 target = transform.position + man.GetComponent<Rigidbody>().velocity;
                target.y = 0;
                //transform.LookAt(target, Vector3.up);
                break;
            case BugState.Alert:
            case BugState.Attack:
                if (man.Target != null)
                {
                    //transform.LookAt(bug.Target.position + (Vector3.up / 3));
                    transform.rotation = Quaternion.RotateTowards(transform.rotation,
                        Quaternion.LookRotation(man.Target.position - transform.position),
                        Time.deltaTime * turningSpeed);
                    //transform.localEulerAngles = new Vector3(0, transform.localEulerAngles.y, transform.localEulerAngles.z);
                    transform.localEulerAngles = new Vector3(0, transform.localEulerAngles.y, 0);
                }
                break;
            default:
                break;
        }
    }

    public void PlayIdleAnimation()
    {
        isWalking = false;
        animator.SetTrigger("idle");
    }

    public void PlayWalkAnimation()
    {
        isWalking = true;
        animator.SetTrigger("walk");
    }

    public void PlayAttackAnimation()
    {
        isWalking = false;
        animator.SetTrigger("attack");
    }

    public void PlayDodgeAnimation(float animLength, bool isRight)
    {
        StartCoroutine(PauseRegularAnimation(animLength));

        float z = isRight ? 360 : -360;

        Vector3 target = new Vector3(transform.rotation.eulerAngles.x, transform.rotation.eulerAngles.y, z);
        transform.DORotate(target, animLength, RotateMode.FastBeyond360);
    }

    public IEnumerator PlayAttackAnimation(float animLength)
    {
        animator.SetBool("isAttacking", true);
        yield return new WaitForSeconds(animLength);
        animator.SetBool("isAttacking", false);
    }

    public void PlayRingOutAnimation()
    {
        transform.DOScale(Vector3.zero, 0.1f);
        var ringOutFx = Instantiate(bugFxPrefabs[(int)BugFX.RingOut],
            transform.position, Quaternion.identity);
        Destroy(ringOutFx, 1f);
    }

    public void PlayBugCollisionFx(Vector3 pos)
    {
        var bugCollsionFx = Instantiate(bugFxPrefabs[(int)BugFX.BugCollision], pos, Quaternion.identity);
        Destroy(bugCollsionFx, 3f);
    }

    public void PlayWaterFloatAnimation(Vector3 pos)
    {
        var waterCollisionFx = Instantiate(bugFxPrefabs[(int)BugFX.WaterCollision], pos, Quaternion.identity);
        Destroy(waterCollisionFx, 3f);

        WaterBobbingAnimation = transform.DOMoveY(
            man.transform.position.y - 0.5f, 1f)
            .SetEase(Ease.OutElastic)
            .SetUpdate(UpdateType.Late);
    }

    public void PlayWaterSinkAnimation(Vector3 pos)
    {
        var waterCollisionFx = Instantiate(bugFxPrefabs[(int)BugFX.WaterCollision], pos, Quaternion.identity);
        Destroy(waterCollisionFx, 3f);

        Vector3 targetPos = pos + man.rb.velocity.normalized;
        targetPos.y -= 0.7f;

        transform.DOMove(targetPos, 1f).SetUpdate(UpdateType.Late).OnComplete(PlayWaterDeathAnimation);
    }

    private void PlayWaterDeathAnimation()
    {
        transform.DOMoveY(transform.position.y + 0.5f, 2f).SetUpdate(UpdateType.Late);

        float zRot = man.ck.CoinToss() ? 180 : -180;

        transform.DORotate(new Vector3(
            transform.rotation.eulerAngles.x,
            transform.rotation.eulerAngles.y,
            zRot), 2f).SetUpdate(UpdateType.Late);

        //man.Kill();
        StartCoroutine(KillAfterT(2f));

        return;
    }

    public void PlayDeathBySpikesAnimation()
    {
        transform.DOMoveY(transform.position.y - 0.5f, 2f).SetUpdate(UpdateType.Late);

        var deathBySpikesFx = Instantiate(bugFxPrefabs[(int)BugFX.DeathBySpikes], transform.position, Quaternion.identity);
        Destroy(deathBySpikesFx, 3f);

        StartCoroutine(KillAfterT(2f));
    }

    // Ability FX
    public void PlayTeleportFx(Vector3 pos)
    {
        var bugCollsionFx = Instantiate(bugFxPrefabs[(int)BugFX.BugCollision], pos, Quaternion.identity);
        Destroy(bugCollsionFx, 3f);
    }

    public void PlayDodgeFx()
    {
        var dodgeFx = Instantiate(bugFxPrefabs[(int)BugFX.Dodge], transform);
        Destroy(dodgeFx, 1f);
    }

    // TODO: Move to BugManager
    private IEnumerator KillAfterT(float t)
    {
        yield return new WaitForSeconds(t);

        Destroy(transform.parent.gameObject);
        var bugDeathFx = Instantiate(bugFxPrefabs[(int)BugFX.BugDeath], transform.position, Quaternion.identity);
        Destroy(bugDeathFx, 3f);

        if (man.bugInfo.numLives > 0)
            man.bugInfo.numLives--;

        // HACK
        man.bsm.PlaySfx(BugSfx.Teleport);
        man.materialiseSfx.parent = null;
    }

    public void PlaySpawnAnimation()
    {
        //transform.DOScale(Vector3.one, 0.5f);
        transform.localScale = Vector3.one;
        StartCoroutine("Blink");
    }

    public void PlayAbilityAnimation(Color colour)
    {
        var abilityFx = Instantiate(bugFxPrefabs[(int)BugFX.Ability], transform.position, Quaternion.identity);
        abilityFx.GetComponent<AbilityFXBehaviour>().SetColour(colour);
        abilityFx.transform.parent = transform;
        Destroy(abilityFx, 3f);
    }

    #region Alert Animation
    public void PlayAlertAnimation(bool isRandom = false)
    {
        float duration = isRandom ? Random.Range(0.5f, 1f) : 0.5f;

        alertGraphic.DOScale(1, 0.5f).SetEase(Ease.OutBounce).OnComplete(ShrinkAlertGraphic);
    }

    private void ShrinkAlertGraphic()
    {
        StartCoroutine(ShrinkAlertGraphicAfterT(1));
    }

    private IEnumerator ShrinkAlertGraphicAfterT(float t)
    {
        yield return new WaitForSeconds(t);
        alertGraphic.DOScale(0, 0.25f);
    }
    #endregion

    public void PlayShootingAnimation()
    {
        isWalking = false;
        animator.SetTrigger("shoot");
    }

    public void Rotate180()
    {
        Vector3 target = new Vector3(transform.rotation.eulerAngles.x,
            transform.rotation.eulerAngles.y - 180,
            transform.rotation.eulerAngles.z);
        transform.DORotate(target, 1, RotateMode.FastBeyond360).SetEase(Ease.OutBack);
    }

    private IEnumerator PauseRegularAnimation(float t)
    {
        pauseMainAnim = true;
        yield return new WaitForSeconds(t);
        pauseMainAnim = false;
    }

    public void ActivateDynamicBone(bool isEnabled)
    {
        if (dynamicBones != null)
        {
            foreach (var bone in dynamicBones)
                bone.enabled = isEnabled;
        }
    }

    public void ActivateHeadRig(bool isEnabled)
    {
        headRig.weight = isEnabled ? 1 : 0;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("target") || other.CompareTag("obstacle"))
        {
            DOTween.To(() => neckBone.m_Stiffness, x => neckBone.m_Stiffness = x, 0.1f, 1);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("target") || other.CompareTag("obstacle"))
        {
            DOTween.To(() => neckBone.m_Stiffness, x => neckBone.m_Stiffness = x, 1, 1);
        }
    }
}
