using System.Collections;
using UnityEngine;

public class ThrowGrenadeAbility : Ability
{
    public override float ActivationTime => 1;

    public override float Length => 1;

    private float angle = 45f;

    public override void DoAbility()
    {
        man.anim.PlayShootingAnimation();
        StartCoroutine(ThrowAfterT(0.5f));
    }

    private IEnumerator ThrowAfterT(float t)
    {
        yield return new WaitForSeconds(t);

        if (man.Target != null)
        {
            var grenade = Instantiate(ah.grenadePrefab, transform.position, Quaternion.identity);
            // Throw grenade
            grenade.velocity = BallisticVelocity(man.Target.position, angle);
        }
    }

    // https://unity3d.college/2017/06/30/unity3d-cannon-projectile-ballistics/
    private Vector3 BallisticVelocity(Vector3 destination, float angle)
    {
        Vector3 dir = destination - transform.position; // get Target Direction
        float height = dir.y; // get height difference
        dir.y = 0; // retain only the horizontal difference
        float dist = dir.magnitude; // get horizontal direction
        float a = angle * Mathf.Deg2Rad; // Convert angle to radians
        dir.y = dist * Mathf.Tan(a); // set dir to the elevation angle.
        dist += height / Mathf.Tan(a); // Correction for small height differences

        // Calculate the velocity magnitude
        float velocity = Mathf.Sqrt(dist * Physics.gravity.magnitude / Mathf.Sin(2 * a));
        return velocity * dir.normalized; // Return a normalized vector.
    }

    public override bool IsObstructed()
    {
        return man.BugState != BugState.Alert || man.Target == null;
    }

    public override bool IsTriggered()
    {
        float minDistance = 3f;

        return man.BugState == BugState.Alert
            && Mathf.Abs((man.Target.position - man.transform.position).magnitude) > minDistance;
        //&& man.bugInfo.GetAtr(AT.Aggression).value > 1;
    }
}
