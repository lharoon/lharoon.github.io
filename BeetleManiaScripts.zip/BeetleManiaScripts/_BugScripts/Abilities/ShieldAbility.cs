public class ShieldAbility : Ability
{
    public override float ActivationTime => throw new System.NotImplementedException();

    public override float Length => throw new System.NotImplementedException();

    public override void DoAbility()
    {
        throw new System.NotImplementedException();
    }

    public override bool IsTriggered()
    {
        throw new System.NotImplementedException();
    }

    public override bool IsObstructed()
    {
        throw new System.NotImplementedException();
    }
}
