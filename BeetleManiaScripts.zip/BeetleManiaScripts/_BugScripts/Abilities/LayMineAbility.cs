using UnityEngine;

public class LayMineAbility : Ability
{
    public override float ActivationTime => 0;

    public override float Length => 0;

    public override void DoAbility()
    {
        var mine = Instantiate(ah.minePrefab, transform.position, Quaternion.identity);

        StartCoroutine(mine.ActivateAfterT(1));
    }

    public override bool IsObstructed()
    {
        return false;
    }

    public override bool IsTriggered()
    {
        return man.BugState == BugState.Retreat;
    }
}
