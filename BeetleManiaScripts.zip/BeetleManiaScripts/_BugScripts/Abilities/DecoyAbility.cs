using DG.Tweening;
using UnityEngine;

public class DecoyAbility : Ability
{
    public override float ActivationTime => 1f;

    public override float Length => 0;

    public override void DoAbility()
    {
        man.bsm.PlaySfx(BugSfx.Teleport);

        // Hide bug
        Vector3 bugSize = man.bmm.transform.localScale;
        man.bmm.transform.localScale = Vector3.zero;
        //man.bmm.transform.DOScale(Vector3.zero, 0.5f);

        // Instantiate decoy
        man.anim.PlayTeleportFx(man.transform.position); // TEMP
        var decoy = Instantiate(ah.decoyPrefab, man.transform.position, Quaternion.identity);
        //target.DOScale(1, 0.5f);
        decoy.rotation = Random.rotation;
        man.TargetBug.SetTarget(decoy);

        Vector3 randomPos = man.transform.position;

        // Find random position that's sufficiently far away
        float minDistance = 4f;
        while (Mathf.Abs((randomPos - man.transform.position).magnitude) < minDistance)
        {
            randomPos = new Vector3(Random.Range(GameInfo.minArenaExt, GameInfo.maxArenaExt),
                man.transform.position.y, Random.Range(GameInfo.minArenaExt, GameInfo.maxArenaExt));
        }

        // Move & show bug
        man.anim.PlayTeleportFx(randomPos); // TEMP
        man.transform.position = randomPos;
        man.bmm.transform.DOScale(bugSize, 0.5f);

        man.SwitchState(BugState.Idle);
    }

    public override bool IsTriggered()
    {
        float minSpeed = 2f; // Speed of attacker
        float minDistance = 1f;

        return
            man.BugState == BugState.Alert &&
            man.TargetBug != null &&
            man.TargetBug.BugState == BugState.Attack &&
            man.TargetBug.rb.velocity.magnitude > minSpeed &&
            Mathf.Abs((man.Target.position - man.transform.position).magnitude) > minDistance;
    }

    public override bool IsObstructed()
    {
        return man.BugState == BugState.Attack
            || man.TargetBug == null;
    }
}
