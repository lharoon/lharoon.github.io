using UnityEngine;

public class DodgeAndStrikeAbility : Ability
{
    public override float ActivationTime => 2f;

    public override float Length => 0;

    private const float dodgeDistance = 3f, chargeSpeed = 500f;

    private Vector3 teleportPos = Vector3.zero;

    public override void DoAbility()
    {
        man.transform.position = teleportPos;
        //man.transform.DOMove(teleportPos, 0.1f);

        man.CurrentStamina = man.ck.GetStamina(); // Reset stamina

        man.mov.MoveToTarget(chargeSpeed); // Charge

        if (man.TargetBug != null)
            man.TargetBug.Stagger();

        man.anim.PlayDodgeFx();

        man.bsm.PlaySfx(BugSfx.Fire);
    }

    public override bool IsTriggered()
    {
        return man.BugState == BugState.Attack
            && man.TargetBug != null
            && man.TargetBug.BugState == BugState.Attack
            && man.CurrentStamina <= 0
            && man.IsBeingPushed;
    }

    public override bool IsObstructed()
    {
        if (man.Target == null) return true;

        Vector3 dir = man.mov.GetDirectionAcrossFromTarget(man.Target);

        teleportPos = transform.position + (dir * dodgeDistance);

        if (ah.IsPosOutOfBounds(teleportPos)) // Check in opposite direction
            teleportPos = transform.position - (dir * dodgeDistance);

        return ah.IsPosOutOfBounds(teleportPos);
    }
}
