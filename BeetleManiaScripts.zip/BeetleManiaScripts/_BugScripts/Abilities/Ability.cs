using UnityEngine;

public abstract class Ability : MonoBehaviour
{
    internal BugManager man;
    internal GameManager gm;
    internal AbilitiesManager am;
    internal AbilityHelper ah;

    public abstract float ActivationTime { get; } // Delay before ability is actioned
    public abstract float Length { get; } // Amount of time to suspend normal behaviour for

    private void Awake()
    {
        man = transform.parent.GetComponent<BugManager>();
        gm = FindObjectOfType<GameManager>();
        am = GetComponent<AbilitiesManager>();
        ah = GetComponent<AbilityHelper>();
    }

    public abstract void DoAbility();

    public abstract bool IsTriggered();

    public abstract bool IsObstructed();
}
