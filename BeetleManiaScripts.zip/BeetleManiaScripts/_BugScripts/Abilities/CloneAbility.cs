using System.Collections;
using BeetleMania;
using DG.Tweening;
using UnityEngine;

public class CloneAbility : Ability
{
    public override float ActivationTime => 2f;

    public override float Length => 0.5f;

    private Vector3 pos1, pos2;

    public override void DoAbility()
    {
        man.bsm.PlaySfx(BugSfx.Teleport); // TEMP

        var clone = Instantiate(man.transform.parent);
        var cloneMan = clone.GetComponentInChildren<BugManager>();
        cloneMan.transform.position = man.transform.position;
        cloneMan.IsClone = true;
        cloneMan.am.RemoveAllGems(); // CHECK
        cloneMan.RemoveHat();
        cloneMan.bmm.HideFlags(); // Unnecessary

        var am = FindObjectOfType<ArenasManager>();
        cloneMan.transform.parent.parent = am.arenas[am.ActiveArenaIdx].transform;

        cloneMan.bugInfo = man.bugInfo;
        cloneMan.SetTarget(man.Target);
        cloneMan.gameObject.layer = LayerMask.NameToLayer("Ghost");

        man.Clone = cloneMan;

        man.anim.PlayTeleportFx(man.transform.position);

        man.transform.DOMove(pos1, Length);
        cloneMan.transform.DOMove(pos2, Length);

        if (man.TargetBug != null && man.ck.CoinToss())
            man.TargetBug.SetTarget(cloneMan.transform);

        StartCoroutine(ResetLayer(cloneMan.gameObject));
    }

    private IEnumerator ResetLayer(GameObject clone)
    {
        yield return new WaitForSeconds(Length);
        clone.layer = LayerMask.NameToLayer("Bug");
    }

    public override bool IsTriggered()
    {
        float minDistance = 2f;

        return man.BugState == BugState.Alert
            //&& man.TargetBug.BugState == BugState.Alert
            && Mathf.Abs((man.Target.position - transform.position).magnitude) > minDistance;
    }

    public override bool IsObstructed()
    {
        if (man.Target == null) return true;

        Vector3 dir = man.mov.GetDirectionAcrossFromTarget(man.Target);
        pos1 = transform.position + dir; pos2 = transform.position - dir;

        return man.BugState != BugState.Alert
            && (ah.IsPosOutOfBounds(pos1) || ah.IsPosOutOfBounds(pos2));
    }
}
