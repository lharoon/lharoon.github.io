using UnityEngine;

public class AbilityHelper : MonoBehaviour
{
    public Transform decoyPrefab;
    public NewMineBehaviour minePrefab;
    public Rigidbody grenadePrefab;

    public bool IsPosOutOfBounds(Vector3 pos)
    {
        return !(pos.x < GameInfo.maxArenaExt && pos.x > GameInfo.minArenaExt &&
            pos.z < GameInfo.maxArenaExt && pos.z > GameInfo.minArenaExt);
    }
}
