using UnityEngine;

public class ShieldBehaviour : MonoBehaviour
{
    public float orbitalSpeed = 400f;
    public float cubeRotationSpeed = 30f;

    public Transform bug;

    public Transform model;

    private void Update()
    {
        transform.position = new Vector3(bug.position.x, 0, bug.position.z);

        transform.Rotate(transform.rotation.eulerAngles.x, orbitalSpeed * Time.deltaTime,
            transform.rotation.eulerAngles.z);

        // Rotate cube
        float deg = cubeRotationSpeed * Time.deltaTime;
        model.Rotate(deg, 0, deg);
    }
}
