using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public enum AbilityType
{
    DodgeAndStrike,
    Decoy,
    Clone,
    LayMine,
    ThrowGrenade
}

public enum GemColour
{
    BROWN,
    GREY,
    RED,
    ORANGE,
    YELLOW,
    //GREEN,
    //BLUE,
    //PINK,
    //WHITE
}

public class AbilitiesManager : MonoBehaviour
{
    #region Inspector fields 
    public BugManager bm;

    public List<SkinnedMeshRenderer> rhinoGems, stagGems, herculesGems;

    public List<Material> gemMaterials;
    #endregion

    private List<Ability> abilities;

    private const float cooldown = 5f;

    // Flags
    private bool isWarmingUp, isCoolingDown;

    private void Start()
    {
        abilities = new List<Ability>()
        {
            gameObject.AddComponent(typeof(DodgeAndStrikeAbility)) as DodgeAndStrikeAbility,
            gameObject.AddComponent(typeof(DecoyAbility)) as DecoyAbility,
            gameObject.AddComponent(typeof(CloneAbility)) as CloneAbility,
            gameObject.AddComponent(typeof(LayMineAbility)) as LayMineAbility,
            gameObject.AddComponent(typeof(ThrowGrenadeAbility)) as ThrowGrenadeAbility
        };

        //foreach (var gem in gems) { gem.gameObject.SetActive(false); }
        foreach (var gem in rhinoGems) { gem.gameObject.SetActive(false); }
        foreach (var gem in stagGems) { gem.gameObject.SetActive(false); }
        foreach (var gem in herculesGems) { gem.gameObject.SetActive(false); }

        foreach (var ability in bm.bugInfo.abilities)
        {
            switch (bm.bugInfo.beetleType)
            {
                case BeetleType.Rhinoceros:
                    rhinoGems[ability.Item2].gameObject.SetActive(true);
                    rhinoGems[ability.Item2].material = gemMaterials[(int)GameInfo.abilityColours[ability.Item1]];
                    break;
                case BeetleType.Stag:
                    stagGems[ability.Item2].gameObject.SetActive(true);
                    stagGems[ability.Item2].material = gemMaterials[(int)GameInfo.abilityColours[ability.Item1]];
                    break;
                case BeetleType.Hercules:
                    herculesGems[ability.Item2].gameObject.SetActive(true);
                    herculesGems[ability.Item2].material = gemMaterials[(int)GameInfo.abilityColours[ability.Item1]];
                    break;
                default:
                    break;
            }
        }
    }

    private void Update()
    {
        if (isWarmingUp || isCoolingDown) return;

        foreach (var ability in bm.bugInfo.abilities)
        {
            if (abilities[(int)ability.Item1].IsTriggered())
            {
                //print(ability);

                StartCoroutine(WarmUp(abilities[(int)ability.Item1], ability));

                break;
            }
        }
    }

    private IEnumerator WarmUp(Ability ability, Tuple<AbilityType, int> abilityTuple)
    {
        bm.bsm.PlaySfx(BugSfx.Ability);

        isWarmingUp = true;

        bm.anim.PlayAbilityAnimation(gemMaterials[(int)GameInfo.abilityColours[abilityTuple.Item1]].color);

        yield return new WaitForSeconds(ability.ActivationTime);

        if (ability.IsObstructed())
        {
            isWarmingUp = false;
            yield break;
        }

        if (ability.Length > 0)
            StartCoroutine(SuspendBehaviour(ability.Length));
        ability.DoAbility();

        if (ability.Length > 0)
            StartCoroutine(RemoveGemAfterT(abilityTuple, ability.Length));
        else
            RemoveGem(abilityTuple);

        StartCoroutine(CoolDown());

        isWarmingUp = false;
    }

    private IEnumerator SuspendBehaviour(float suspensionTime)
    {
        bm.IsBehaviourSuspended = true;
        yield return new WaitForSeconds(suspensionTime);
        bm.IsBehaviourSuspended = false;
    }

    private IEnumerator RemoveGemAfterT(Tuple<AbilityType, int> abilityTuple, float t)
    {
        yield return new WaitForSeconds(t);
        RemoveGem(abilityTuple);
    }

    private void RemoveGem(Tuple<AbilityType, int> abilityTuple)
    {
        switch (bm.bugInfo.beetleType)
        {
            case BeetleType.Rhinoceros:
                rhinoGems[abilityTuple.Item2].gameObject.SetActive(false);
                break;
            case BeetleType.Stag:
                stagGems[abilityTuple.Item2].gameObject.SetActive(false);
                break;
            case BeetleType.Hercules:
                herculesGems[abilityTuple.Item2].gameObject.SetActive(false);
                break;
            default:
                break;
        }

        bm.bugInfo.abilities.Remove(abilityTuple);
    }

    private IEnumerator CoolDown()
    {
        isCoolingDown = true;
        yield return new WaitForSeconds(cooldown);
        isCoolingDown = false;
    }

    public void RemoveAllGems()
    {
        //foreach (var gem in gems) { gem.gameObject.SetActive(false); }
        foreach (var gem in rhinoGems) { gem.gameObject.SetActive(false); }
        foreach (var gem in stagGems) { gem.gameObject.SetActive(false); }
        foreach (var gem in herculesGems) { gem.gameObject.SetActive(false); }
        Destroy(gameObject);
    }
}
