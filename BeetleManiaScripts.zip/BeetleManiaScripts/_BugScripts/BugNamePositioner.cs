using TMPro;
using UnityEngine;

public class BugNamePositioner : MonoBehaviour
{
    public BugManager bug;

    private TextMeshPro nameText;

    private void Start()
    {
        nameText = GetComponent<TextMeshPro>();
        nameText.text = bug.bugInfo.bugName;
    }

    private void Update()
    {
        transform.position = bug.transform.position;

        if (bug.bugInfo.bugName != nameText.text)
            nameText.text = bug.bugInfo.bugName;
    }

    void LateUpdate()
    {
        transform.LookAt(Camera.main.transform);
        transform.rotation = Quaternion.LookRotation(Camera.main.transform.forward);
    }
}
