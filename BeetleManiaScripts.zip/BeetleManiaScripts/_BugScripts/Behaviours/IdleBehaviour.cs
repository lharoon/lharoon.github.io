public class IdleBehaviour : StateBehaviour
{
    public float speedMultiplier = 1f;

    private bool isProvoked;

    public override void Behave()
    {
        if (man.IsBehaviourSuspended) return;

        OnUpdate();
        OnTick();
    }

    public override void OnEntry()
    {
        anim.PlayWalkAnimation();
    }

    public override void OnUpdate()
    {
        mov.SeekFood(ck.GetSpeed() * speedMultiplier);

        if (isProvoked)
            man.SwitchState(BugState.Alert);
    }

    public override void OnTick()
    {
        if (!man.CheckTick()) return;

        if ((man.TargetBug != null && ck.SpotCheck(man.TargetBug.bugInfo.GetValue(AT.Stealth)))
           || (man.Target != null && man.TargetBug == null)) // For cubes
        {
            if (ck.CourageCheck())
                man.SwitchState(BugState.Alert);
            else
                man.SwitchState(BugState.Retreat);
        }
        //else if (man.Target != null)
        //{
        //    if (ck.CourageCheck())
        //        man.SwitchState(BugState.Alert);
        //    else
        //        man.SwitchState(BugState.Retreat);
        //}
    }

    public override void OnExit()
    {
        isProvoked = false;
    }

    private void OnTriggerStay(UnityEngine.Collider other)
    {
        if (man.BugState != BugState.Idle)
            return;

        if (other.CompareTag("target"))
        {
            if (man.Target == null)
                man.SetTarget(other.transform);
        }
    }

    private void OnTriggerExit(UnityEngine.Collider other)
    {
        if (man.BugState != BugState.Idle)
            return;

        if (other.CompareTag("target"))
            man.UnsetTarget();
    }

    private void OnCollisionEnter(UnityEngine.Collision collision)
    {
        if (man.BugState != BugState.Idle)
            return;

        if (collision.gameObject.CompareTag("target"))
        //||
        //collision.gameObject.CompareTag("projectile"))
        {
            if (!man.IsDead)
                isProvoked = true;
        }
    }
}
