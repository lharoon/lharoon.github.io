public class DeadBehaviour : StateBehaviour
{
    public override void Behave()
    {
        if (man.IsBehaviourSuspended) return;

        OnTick();
        OnUpdate();
    }

    public override void OnEntry()
    {
    }

    public override void OnExit() { }

    public override void OnTick() { }

    public override void OnUpdate() { }
}
