using UnityEngine;

public class AlertBehaviour : StateBehaviour
{
    public float speedMultiplier = 0.5f;

    public override void Behave()
    {
        if (man.IsBehaviourSuspended) return;

        OnUpdate();
        OnTick();
    }

    public override void OnEntry()
    {
        anim.PlayWalkAnimation();
        //anim.PlayAlertAnimation();
    }

    public override void OnUpdate()
    {
        //if (man.IsTooClose())
        //    mov.MoveAwayFromTarget(ck.GetSpeed());
        //else
        man.mov.SeekFood(ck.GetSpeed() * speedMultiplier);
        //mov.MoveAcrossFromTarget(alertSpeed);
    }

    public override void OnTick()
    {
        if (!man.CheckTick()) return;

        if (ck.AggressionCheck())
        {
            //if (!man.IsTooClose())
            //if (!man.IsClone)
            man.SwitchState(BugState.Attack);
        }
    }

    public override void OnExit() { }

    private void OnTriggerExit(Collider other)
    {
        if (man.BugState != BugState.Alert)
            return;

        if (other.transform == man.Target) // Maybe unnecessary
            man.UnsetTarget();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (man.BugState != BugState.Alert)
            return;

        if (collision.gameObject.CompareTag("target"))
        {
            //if (!man.IsClone) // Unnecessary
            man.SwitchState(BugState.Attack);
        }
    }
}
