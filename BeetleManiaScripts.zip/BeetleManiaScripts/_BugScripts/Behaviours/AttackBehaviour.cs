using System.Collections;
using UnityEngine;

public class AttackBehaviour : StateBehaviour
{
    public float speedMultiplier = 2f;
    public float recoveryRate = 1f;

    private bool isPushingCube; // TEMP
    private bool hasSteppedBack = true;

    private float timeAtZero = 0;
    private const float minVel = 0.5f, maxTimeAtZero = 3f;

    private void Update()
    {
        if (man.IsBeingPushed || isPushingCube)
        {
            if (man.CurrentStamina > 0)
                man.CurrentStamina -= Time.deltaTime;
        }
        else
        {
            if (man.CurrentStamina < ck.GetStamina())
                man.CurrentStamina += Time.deltaTime * recoveryRate;
        }
    }

    public override void Behave()
    {
        if (man.IsBehaviourSuspended) return;

        OnUpdate();
        OnTick();
    }

    public override void OnEntry()
    {
        anim.PlayWalkAnimation();

        if (man.IsTooClose())
            StartCoroutine("StepBack");
        else
        {
            //StartCoroutine(anim.PlayAttackAnim(1f));
            if (!man.IsDead && !man.IsOutOfRing) // TEMP
                gm.SwitchToCam(VCType.ClashCam, transform);
        }
    }

    private IEnumerator StepBack()
    {
        hasSteppedBack = false;

        float t = 0;

        while (t < 1f)
        {
            mov.MoveAwayFromTarget(ck.GetSpeed() / 2f);
            t += Time.deltaTime;
            yield return null;
        }

        hasSteppedBack = true;

        //StartCoroutine(anim.PlayAttackAnim(1f));
        if (!man.IsDead && !man.IsOutOfRing) // TEMP
            gm.SwitchToCam(VCType.ClashCam, transform);
    }

    public override void OnUpdate()
    {
        if (!hasSteppedBack
            || anim.animator.GetCurrentAnimatorStateInfo(0).IsName("Armature|attack ready"))
            return;

        float attackSpeed = ck.GetSpeed() * speedMultiplier;

        // Charge
        mov.MoveToTarget(attackSpeed * man.CurrentStamina / ck.GetStamina());

        if (mov.Rigidbody.velocity.magnitude < minVel)
        {
            timeAtZero += Time.deltaTime;

            if (timeAtZero >= maxTimeAtZero)
                man.SwitchState(BugState.Alert);
        }
        else
        {
            timeAtZero = 0;
        }
    }

    public override void OnTick()
    {
        if (!man.CheckTick()) return;
    }

    public override void OnExit()
    {
        gm.SwitchToCam(VCType.ArenaCam);

        isPushingCube = false;
        hasSteppedBack = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (man.BugState != BugState.Attack)
            return;

        if (collision.transform == man.Target && collision.relativeVelocity.magnitude > 3)
        {
            anim.PlayBugCollisionFx(collision.GetContact(0).point);
            man.bsm.PlaySfx(BugSfx.Collision);
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        //if (man.BugState != BugState.Attack)
        //    return;

        if (collision.gameObject.CompareTag("target"))
        {
            var bug = collision.gameObject.GetComponent<BugManager>();

            if (bug != null)
            {
                //if (bug.BugState == BugState.Attack)
                bug.IsBeingPushed = man.CurrentStamina > 0; // ?
            }
            else
                isPushingCube = true;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("target"))
        {
            var bug = collision.gameObject.GetComponent<BugManager>();

            if (bug != null)
                bug.IsBeingPushed = false;
            else
                isPushingCube = false;
        }
    }
}
