public class NullBehaviour : StateBehaviour
{
    public override void Behave()
    {
        OnTick();
        OnUpdate();
    }

    public override void OnEntry() { }

    public override void OnExit() { }

    public override void OnTick() { }

    public override void OnUpdate() { }
}
