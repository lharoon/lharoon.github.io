public class RetreatBehaviour : StateBehaviour
{
    public float speedMultiplier = 2f;

    public override void Behave()
    {
        if (man.IsBehaviourSuspended) return;

        OnUpdate();
        OnTick();
    }

    public override void OnEntry()
    {
        anim.PlayWalkAnimation();
    }

    public override void OnExit()
    {
        man.UnsetTarget();
    }

    public override void OnTick()
    {
        if (!man.CheckTick()) return;

        // TEMP
        if (ck.CoinToss())
        {
            man.UnsetTarget();
            man.SwitchState(BugState.Idle);
        }
    }

    public override void OnUpdate()
    {
        mov.MoveAwayFromTarget(ck.GetSpeed() * speedMultiplier);
    }

    private void OnTriggerExit(UnityEngine.Collider other)
    {
        if (man.BugState != BugState.Retreat)
            return;

        if (other.transform == man.Target)
        {
            man.UnsetTarget();
            man.SwitchState(BugState.Idle);
        }
    }
}
