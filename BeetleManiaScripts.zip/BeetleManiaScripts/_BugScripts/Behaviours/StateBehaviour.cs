using UnityEngine;

public abstract class StateBehaviour : MonoBehaviour
{
    internal GameManager gm;

    internal BugManager man;

    internal BugMover mov;
    internal AttributeChecker ck;
    internal BugAnimator anim;

    internal float minThreshold = 0.25f, maxThreshold = 0.75f;

    private void Awake()
    {
        gm = FindObjectOfType<GameManager>();

        man = transform.parent.GetComponentInChildren<BugManager>();
        mov = transform.parent.GetComponentInChildren<BugMover>();
        ck = transform.parent.GetComponentInChildren<AttributeChecker>();
        anim = transform.parent.GetComponentInChildren<BugAnimator>();
    }

    public abstract void Behave();

    public abstract void OnEntry();
    public abstract void OnUpdate();
    public abstract void OnTick();
    public abstract void OnExit();
}
