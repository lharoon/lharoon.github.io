using System.Collections.Generic;
using UnityEngine;

public class BugModelManager : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public List<GameObject> bugModels; // TODO: Remove
    public List<Material> bugMaterials;

    public MeshRenderer spawnPad, cross;
    public List<SkinnedMeshRenderer> rhinoGems, stagGems, herculesGems;
    public List<GameObject> rhinoParts, stagParts, herculesParts;
    public List<GameObject> hats;
    public List<GameObject> flags;

    public BugManager man;

    public Outline outline;

    #endregion

    private int activeModelIdx;

    private float size;

    private void Start()
    {
        DeactivateAllParts();

        switch (man.bugInfo.beetleType)
        {
            case BeetleType.Rhinoceros:
                ActivateParts(rhinoParts, true);
                break;
            case BeetleType.Stag:
                ActivateParts(stagParts, true);
                break;
            case BeetleType.Hercules:
                ActivateParts(herculesParts, true);
                break;
            default:
                break;
        }

        hats[man.bugInfo.hatIdx].SetActive(true);
    }

    private void DeactivateAllParts()
    {
        ActivateParts(rhinoParts, false);
        ActivateParts(stagParts, false);
        ActivateParts(herculesParts, false);
    }

    private void ActivateParts(List<GameObject> parts, bool isEnabled)
    {
        foreach (var part in parts)
        {
            part.SetActive(isEnabled);
        }
    }

    private void Update()
    {
        if (size != man.ck.GetSize() && FindObjectOfType<TrailerManager>() == null) // TEMP
        {
            size = man.ck.GetSize();
            man.transform.localScale = new Vector3(size, size, size);
            transform.localScale = new Vector3(size, size, size);

            ScaleFlag(flags[0].transform);
            ScaleFlag(flags[1].transform);
            ScaleFlag(flags[2].transform);
            ScaleFlag(flags[3].transform);
        }

        if (!man.IsClone)
            ActivateFlags();
    }

    private void ScaleFlag(Transform flag)
    {
        float newScale = flag.localScale.x / size;
        flag.localScale = new Vector3(newScale, newScale, newScale);
    }

    private void ActivateFlags()
    {
        // TODO: Use enum
        flags[0].SetActive(man.bugInfo.isSemis);
        flags[1].SetActive(man.bugInfo.isFinals);
        flags[2].SetActive(man.bugInfo.isChampion);
        flags[3].SetActive(man.bugInfo.isMatch);
    }

    public void HideFlags()
    {
        foreach (var flag in flags)
        {
            flag.SetActive(false);
        }
    }

    public void SetModel(int idx)
    {
        activeModelIdx = idx;

        for (int i = 0; i < bugModels.Count; i++)
            bugModels[i].SetActive(i == activeModelIdx);
    }

    public void SetMaterial(int idx)
    {
        var mat = bugMaterials[idx];
        var meshRenderers = bugModels[activeModelIdx].GetComponentsInChildren<SkinnedMeshRenderer>();
        foreach (var mr in meshRenderers)
            mr.material = mat;
        spawnPad.material = mat;
    }

    public void SetRandom()
    {
        RandomiseModel();
        RandomiseMaterial();
    }

    public void RandomiseModel()
    {
        activeModelIdx = Random.Range(0, bugModels.Count);

        for (int i = 0; i < bugModels.Count; i++)
            bugModels[i].SetActive(i == activeModelIdx);

        man.bugInfo.modelIdx = activeModelIdx;
    }

    public void RandomiseMaterial()
    {
        int activeMaterialIdx = Random.Range(0, bugMaterials.Count);
        var mat = bugMaterials[activeMaterialIdx];
        var meshRenderers = bugModels[activeModelIdx].GetComponentsInChildren<SkinnedMeshRenderer>();
        foreach (var mr in meshRenderers)
            mr.material = mat;
        spawnPad.material = mat;
        cross.material = mat;

        man.bugInfo.materialIdx = activeMaterialIdx;
    }

    public void SetMaterial(Material mat)
    {
        var meshRenderers = bugModels[activeModelIdx].GetComponentsInChildren<SkinnedMeshRenderer>();
        foreach (var mr in meshRenderers)
            mr.material = mat;
        spawnPad.material = mat;
        cross.material = mat;
    }

    public void SetHatMaterial(Material mat)
    {
        //foreach (var hat in hats)
        //{
        //    foreach (var mr in hat.GetComponentsInChildren<MeshRenderer>())
        //        mr.material = mat;
        //}
    }
}
