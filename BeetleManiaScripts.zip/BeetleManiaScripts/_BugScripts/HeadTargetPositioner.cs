using DG.Tweening;
using UnityEngine;

public class HeadTargetPositioner : MonoBehaviour
{
    public BugManager bugManager;

    private void Update()
    {
        if (bugManager.Target != null)
        {
            transform.DOMove(bugManager.Target.position, bugManager.rb.velocity.magnitude);
        }
        else if (bugManager.TargetFood != null)
        {
            transform.DOMove(bugManager.TargetFood.position, bugManager.rb.velocity.magnitude);
        }
    }
}
