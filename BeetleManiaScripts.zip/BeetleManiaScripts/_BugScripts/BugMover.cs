using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class BugMover : MonoBehaviour
{
    private Rigidbody rb;
    public Rigidbody Rigidbody { get { return rb; } }

    private BugManager man;
    private BugAnimator anim;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        man = GetComponent<BugManager>();
        anim = transform.parent.GetComponentInChildren<BugAnimator>();

        // https://forum.unity.com/threads/rigidbody-with-multiple-colliders.524352/
        rb.centerOfMass = Vector3.zero;
        rb.inertiaTensorRotation = new Quaternion(0, 0, 0, 1);
    }

    public void MoveToTarget(float speed)
    {
        if (man.Target != null) // Check outside?
            rb.AddForce(GetDirection(man.Target) * speed);
    }

    public void MoveToTarget(Transform target, float speed)
    {
        rb.AddForce(GetDirection(target) * speed);
    }

    public void MoveAcrossFromTarget(float speed)
    {
        if (man.Target != null)
        {
            Vector3 direction = Vector3.Cross(GetDirection(man.Target), Vector3.up).normalized;
            rb.AddForce(direction * speed);
        }
    }

    public void MoveAcrossFromTarget(Transform target, float speed)
    {
        Vector3 direction = Vector3.Cross(GetDirection(target), Vector3.up).normalized;
        rb.AddForce(direction * speed);
    }

    public Vector3 GetDirectionAcrossFromTarget(Transform target)
    {
        return Vector3.Cross(GetDirection(target), Vector3.up).normalized;
    }

    private Vector3 GetDirection(Transform target)
    {
        Vector3 direction = target.position - transform.position;
        direction.y = 0;
        return direction.normalized;
    }

    public void MoveInDirection(Vector3 direction, float speed)
    {
        rb.AddForce(direction * speed);
    }

    public void SeekFood(float speed)
    {
        var targetObj = ObjUtils.GetNearestObject("dot", transform.position, layer: gameObject.layer);
        if (targetObj != null)
        {
            MoveToTarget(targetObj.transform, speed);
            man.TargetFood = targetObj.transform; // For aiming head
        }
    }

    public IEnumerator Dodge(float duration, float speed)
    {
        bool isRight = speed >= 0;
        anim.PlayDodgeAnimation(duration, isRight);

        float t = 0;

        while (t < duration)
        {
            MoveAcrossFromTarget(speed);
            t += Time.deltaTime;
            yield return null;
        }
    }

    public void MoveAwayFromTarget(float speed)
    {
        MoveToTarget(-speed);
    }

    //public void FallOffArena()
    //{
    //    rb.velocity = rb.velocity; // Maintain velocity
    //}
}
