using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public enum BugState { Null, Idle, Alert, Attack, Retreat, Dead }

public class BugManager : MonoBehaviour
{
    public BugInfo bugInfo = new BugInfo();

    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public SphereCollider radar;

    public BugMover mov;
    public AttributeChecker ck;
    public Rigidbody rb;

    // TODO: Expose as properties
    public BugModelManager bmm;
    public BugAnimator anim;
    public AbilitiesManager am;
    public BugSfxManager bsm;

    public TextMeshPro bugNameText;

    public bool isDynamicBoneOn, isHeadRigOn;
    public bool isBox;

    public GameObject hat;

    public Transform fallSfx, materialiseSfx; // HACK
    #endregion

    private StateBehaviour activeBehaviour;
    private List<StateBehaviour> behaviours;

    private GameManager gm; // TODO: Rename

    private float tick, elapsedTime;

    private const float minDistance = 2.5f;

    public BugState BugState { get; set; }
    public Transform Target { get; set; }
    public BugManager TargetBug { get; set; }
    public Transform TargetFood { get; set; } // For aiming head
    public float CurrentStamina { get; set; }
    public BugManager Clone { get; set; }

    #region Flags
    public bool IsBeingPushed { get; set; }
    public bool IsDead { get; set; }
    public bool IsOutOfRing { get; set; } // TEMP
    public bool IsOnWater { get; set; }
    public bool HasDrowned { get; set; } // TODO: Use states for death anims
    public bool IsBehaviourSuspended { get; set; }
    public bool IsInanimate { get; set; }
    public bool IsClone { get; set; } // TODO: Move to BugInfo?
    public bool IsGrounded { get; set; }

    private bool hasJustSetTarget;
    private bool hasHatFallen;
    #endregion

    private void Awake()
    {
        ck = GetComponent<AttributeChecker>();
        gm = FindObjectOfType<GameManager>();

        // TEMP
        if (PlayerPrefs.HasKey(bugInfo.bugName))
            bugInfo.notes = PlayerPrefs.GetString(bugInfo.bugName);
    }

    private void Start()
    {
        if (IsClone)
        {
            behaviours = new List<StateBehaviour>()
            {
                gameObject.GetComponent<NullBehaviour>(),
                gameObject.GetComponent<IdleBehaviour>(),
                gameObject.GetComponent<AlertBehaviour>(),
                gameObject.GetComponent<AttackBehaviour>(),
                gameObject.GetComponent<RetreatBehaviour>(),
                gameObject.GetComponent<DeadBehaviour>()
            };
            SwitchState(BugState.Alert);
        }
        else
        {
            behaviours = new List<StateBehaviour>()
            {
                gameObject.AddComponent(typeof(NullBehaviour)) as NullBehaviour,
                gameObject.AddComponent(typeof(IdleBehaviour)) as IdleBehaviour,
                gameObject.AddComponent(typeof(AlertBehaviour)) as AlertBehaviour,
                gameObject.AddComponent(typeof(AttackBehaviour)) as AttackBehaviour,
                gameObject.AddComponent(typeof(RetreatBehaviour)) as RetreatBehaviour,
                gameObject.AddComponent(typeof(DeadBehaviour)) as DeadBehaviour
            };
            activeBehaviour = behaviours[0];
        }

        tick = 1f; // 1s
        CurrentStamina = ck.GetStamina();

        if (BugState == BugState.Null && FindObjectOfType<TrailerManager>() == null // TEMP
            && !IsInanimate)
            SwitchState(BugState.Idle);

        // Enable underlying collider
        GetComponent<SphereCollider>().enabled = !isBox;
        GetComponent<BoxCollider>().enabled = isBox;
    }

    private void Update()
    {
        elapsedTime += Time.deltaTime;
        Behave();
    }

    private void FixedUpdate()
    {
        activeBehaviour.Behave();
    }

    private void Behave()
    {
        OnUpdate();
        OnTick();
    }

    private void OnUpdate()
    {
        SetRadarRadius();

        if (Target == null || (TargetBug != null && TargetBug.IsDead))
            UnsetTarget();

        // Out of spotting range
        if (Target == null && BugState != BugState.Null)
        {
            SwitchState(BugState.Idle);
            if (gm.ActiveCam != VCType.ClashCam) gm.SwitchToCam(VCType.ArenaCam); // Neccessary?
        }
    }

    private void SetRadarRadius()
    {
        if (IsOnWater)
            radar.radius = 0;
        else if (BugState == BugState.Alert)
            radar.radius = ck.GetRange() * 1.5f;
        else
            radar.radius = ck.GetRange();
    }

    private void OnTick() { }

    public void SwitchState(BugState state)
    {
        //print(BugState);

        if (BugState != BugState.Dead)
        {
            if (BugState != state)
                Switch(state);
        }
    }

    public IEnumerator SwitchState(BugState state, float t)
    {
        yield return new WaitForSeconds(t);

        if (BugState != state)
            Switch(state);
    }

    private void Switch(BugState state)
    {
        if (activeBehaviour != null)
            activeBehaviour.OnExit();

        BugState = state;
        activeBehaviour = behaviours[(int)state];
        activeBehaviour.OnEntry();
    }

    public bool CheckTick()
    {
        if (elapsedTime > tick)
        {
            elapsedTime = 0;
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool IsTooClose()
    {
        if (Target != null)
            return Vector3.Distance(transform.position, Target.transform.position) < minDistance;
        else
            return false;
    }

    public void SetTarget(Transform tgtTransform)
    {
        Target = tgtTransform;
        TargetBug = tgtTransform.GetComponent<BugManager>();

        StartCoroutine("TargetSetCooldown");
    }

    private IEnumerator TargetSetCooldown()
    {
        hasJustSetTarget = true;
        yield return new WaitForSeconds(3f);
        hasJustSetTarget = false;
    }

    public void UnsetTarget()
    {
        Target = null;
        TargetBug = null;
    }

    public bool IsTargetSet()
    {
        return Target != null && TargetBug != null;
    }

    public IEnumerator RespawnAfterT(float t)
    {
        yield return new WaitForSeconds(t);

        anim.PlaySpawnAnimation();
        SwitchState(BugState.Idle);

        yield return new WaitForSeconds(t);
        IsDead = false;
        //tag = "target";
    }

    public void Stagger()
    {
        CurrentStamina = 0;
    }

    public IEnumerator KillAfterT(float t)
    {
        //IsDead = true; // TEMP
        yield return new WaitForSeconds(t);
        Kill();
    }

    public void Kill()
    {
        if (IsDead) return;

        IsDead = true;
        //tag = "Untagged";

        anim.PlayTeleportFx(transform.position); // TODO: Replace with actual fx

        Destroy(transform.parent.gameObject, 0.1f);

        if (!IsClone)
            bugInfo.numLives--;

        if (Clone != null)
            Clone.KillClone();

        bsm.PlaySfx(BugSfx.Teleport);
        materialiseSfx.parent = null; // HACK
    }

    public void KillClone()
    {
        anim.PlayBugCollisionFx(transform.position); // TODO: Replace with actual fx
        Destroy(transform.parent.gameObject, 0.1f);
    }

    public void ActivateColliders(bool isEnabled)
    {
        foreach (var collider in GetComponents<Collider>())
            collider.enabled = isEnabled;
    }

    public void SetModelAndMat()
    {
        bmm.SetModel(bugInfo.modelIdx);
        bmm.SetMaterial(bugInfo.materialIdx);
    }

    public void RandomiseAttributeValues() // TODO: Remove & replace references with BugInfo method
    {
        foreach (var atr in bugInfo.attributes)
            atr.value = Random.Range(GameInfo.minAtrVal, GameInfo.maxAtrVal + 1);
    }

    public void MaximiseAttributeValues()
    {
        foreach (var atr in bugInfo.attributes)
            atr.value = GameInfo.maxAtrVal;
    }

    public void MinimiseAttributeValues()
    {
        foreach (var atr in bugInfo.attributes)
            atr.value = GameInfo.minAtrVal;
    }

    public void RemoveHat()
    {
        hasHatFallen = true;
        hat.SetActive(false);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!hasHatFallen && collision.relativeVelocity.magnitude > 3)
        {
            var hatCopy = Instantiate(hat, hat.transform.position, Quaternion.identity);
            hatCopy.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            hat.SetActive(false);

            // Knock hat off

            var hatRb = hatCopy.GetComponent<Rigidbody>();
            if (hatRb == null)
                hatRb = hatCopy.AddComponent<Rigidbody>();
            //hatRb.mass = 0.1f;
            hatCopy.GetComponent<Collider>().enabled = true;
            hatCopy.transform.parent = null;
            //Vector3 dir = (collision.transform.position - transform.position).normalized;
            hatRb.AddForce(collision.relativeVelocity);

            hasHatFallen = true;
        }

        if (collision.gameObject.CompareTag("barrier"))
        {
            SwitchState(BugState.Dead);
            Kill();
        }

        if (collision.gameObject.CompareTag("target") && collision.gameObject != gameObject)
        //||
        //collision.gameObject.CompareTag("projectile"))
        {
            if (BugState != BugState.Retreat && !hasJustSetTarget)
            {
                if (ck.CoinToss())
                    SetTarget(collision.transform);
            }
        }

        if (collision.gameObject.CompareTag("floor"))
        {
            var floorMesh = collision.gameObject.GetComponent<MeshRenderer>();
            if (floorMesh != null)
            {
                var floorMat = collision.gameObject.GetComponent<MeshRenderer>().material;

                if (floorMat != null && bugInfo.material != null)
                {
                    float deltaE = (float)ColourUtils.CalculateDeltaE(bugInfo.material.color, floorMat.color);

                    // Update stealth value
                    if (deltaE == 0)
                        bugInfo.SetValue(AT.Stealth, 3);
                    else if (deltaE <= 25)
                        bugInfo.SetValue(AT.Stealth, 2);
                    else if (deltaE <= 50)
                        bugInfo.SetValue(AT.Stealth, 1);
                    else
                        bugInfo.SetValue(AT.Stealth, 0);
                }
            }

            // Reset water variables
            IsOnWater = false;
            anim.WaterBobbingAnimation.Kill();
            anim.SetPosition();

            IsGrounded = true;
        }

        if (collision.gameObject.CompareTag("water"))
        {
            IsOnWater = true;
            if (ck.FloatCheck())
            {
                anim.PlayWaterFloatAnimation(collision.GetContact(0).point);
                SwitchState(BugState.Idle);
            }
            else
            {
                anim.PlayWaterSinkAnimation(collision.GetContact(0).point);
                SwitchState(BugState.Dead);
                //HasDrowned = true;
                IsDead = true;
            }

            bsm.PlaySfx(BugSfx.Splash);
            IsGrounded = false;
        }

        if (collision.gameObject.CompareTag("spikes"))
        {
            var holeInfo = collision.gameObject.GetComponent<HoleInfo>();
            if (!ck.PassOverHoleCheck(holeInfo.HoleSize))
            {
                anim.PlayDeathBySpikesAnimation();
                SwitchState(BugState.Dead);
                IsDead = true;
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("floor"))
        {
            IsGrounded = false;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("boundary"))
        {
            if (!IsOutOfRing)
            {
                if (TargetBug != null) // TEMP
                {
                    TargetBug.UnsetTarget();
                    TargetBug.rb.velocity = Vector3.zero;
                }

                SwitchState(BugState.Dead);
                IsOutOfRing = true;
                tag = "Untagged";
                StartCoroutine(KillAfterT(2));

                bsm.PlaySfx(BugSfx.Fall);
                fallSfx.parent = null; // HACK
            }
        }
    }

    private void OnMouseEnter()
    {
        bugNameText.DOKill();
        bugNameText.DOFade(1, 0.1f);
    }

    private void OnMouseExit()
    {
        bugNameText.DOKill();
        bugNameText.DOFade(0, 0.5f);
    }
}
