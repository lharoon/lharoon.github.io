using DG.Tweening;
using UnityEngine;

public class AlertIndicatorBehaviour : MonoBehaviour
{
    public BugManager bug;

    private bool isShown;

    private void Update()
    {
        transform.position = new Vector3(bug.transform.position.x,
                transform.position.y, bug.transform.position.z);

        // Show
        if (!isShown &&
            (bug.BugState == BugState.Alert ||
            bug.BugState == BugState.Attack))
        {
            //transform.DOScale(new Vector3(0.25f, 0.25f, 0.25f), 0.5f);
            transform.DOScale(Vector3.one, 0.25f);
            isShown = true;
        }
        // Hide
        else if (bug.BugState == BugState.Idle || bug.BugState == BugState.Null)
        {
            transform.DOScale(new Vector3(0, 0, 0), 0.5f);
            isShown = false;
        }
    }
}
