using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;

public class PlatformBehaviour : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public SpawnPointBehaviour spawnPoint;
    public Light spotLight;
    public TextMeshPro bugNameLeft, bugNameRight;

    public bool isOnRightSide;

    public List<GameObject> coins;
    #endregion

    private const float lightIntensity = 2;

    private bool hasBrightened;

    private void Start()
    {
        spotLight.intensity = 0;
        bugNameLeft.text = spawnPoint.bugInfo.bugName;
        bugNameRight.text = spawnPoint.bugInfo.bugName;

        spawnPoint.bugInfo.numLives = 1; // Reset lives count (TEMP)
    }

    private void Update()
    {
        if (hasBrightened) return;

        switch (GameInfo.currentRound)
        {
            //case RoundNum.Zero:
            case RoundNum.One:
            case RoundNum.Two:
            case RoundNum.Three:
                if (GameInfo.bugIdx < GameInfo.bugs.Count - 1) // TEMP
                {
                    if (spawnPoint.bugInfo == GameInfo.bugs[GameInfo.bugIdx] ||
                        spawnPoint.bugInfo == GameInfo.bugs[GameInfo.bugIdx + 1])
                    {
                        Brighten(); hasBrightened = true;
                    }
                }
                break;
            case RoundNum.Four:
            case RoundNum.Five:
            case RoundNum.Six:
                if (GameInfo.winnerIdx < GameInfo.roundWinners.Count - 1) // TEMP
                {
                    if (spawnPoint.bugInfo == GameInfo.roundWinners[GameInfo.winnerIdx] ||
                        spawnPoint.bugInfo == GameInfo.roundWinners[GameInfo.winnerIdx + 1])
                    {
                        Brighten(); hasBrightened = true;
                    }
                }
                break;
            case RoundNum.Fin:
                if (spawnPoint.bugInfo.roundLevel == RoundLevel.Champ)
                {
                    Brighten(); hasBrightened = true;
                }
                break;
        }
    }

    public void Brighten()
    {
        spotLight.DOIntensity(lightIntensity, 0.5f);
    }

    public void Dim()
    {
        spotLight.DOIntensity(0, 0.5f);
    }
}
