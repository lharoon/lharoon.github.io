using System.Collections.Generic;
using Cinemachine;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public enum VCType { ArenaCam, ClashCam }

public enum TargetType { None, Bug, Target }

public class GameManager : MonoBehaviour // TODO: Rename to CameraManager
{
    public List<CinemachineVirtualCamera> virtualCameras;

    public AudioSource bgm;

    private VCType activeCam = VCType.ArenaCam;
    public VCType ActiveCam { get { return activeCam; } }

    public Toggle soundToggle, bgmToggle;
    public AudioMixer audioMixer;

    private void Update()
    {
        if (activeCam == VCType.ClashCam)
        {
            if (virtualCameras[(int)activeCam].LookAt == null)
                SwitchToCam(VCType.ArenaCam);
        }
    }

    public void SwitchToCam(VCType requestedCam, Transform lookAtTgt = null)
    {
        if (virtualCameras.Count == 0) return;

        if (requestedCam != activeCam)
        {
            virtualCameras[(int)activeCam].gameObject.SetActive(false);
            virtualCameras[(int)requestedCam].gameObject.SetActive(true);
            virtualCameras[(int)requestedCam].LookAt = lookAtTgt;
            activeCam = requestedCam;
        }
    }

    public void ResetCam()
    {
        virtualCameras[(int)VCType.ClashCam].gameObject.SetActive(false);
        virtualCameras[(int)VCType.ArenaCam].gameObject.SetActive(true);
        virtualCameras[(int)VCType.ArenaCam].LookAt = null;
        activeCam = VCType.ArenaCam;
    }

    public void ToggleSound() // TODO: Move
    {
        GameInfo.playSfx = soundToggle.isOn;
    }

    public void ToggleMusic() // TODO: Move
    {
        GameInfo.playBgm = bgmToggle.isOn;

        if (bgmToggle.isOn)
            bgm.Play();
        else
            bgm.Stop();
    }
}
