using System.Collections.Generic;
using UnityEngine;

public class BugSelector : MonoBehaviour
{
    public bool previewSelection;

    public BugManager SelectedBug { get; set; }

    private List<BugManager> bugs = new List<BugManager>();
    private int selectedBugIdx;

    private BugManager highlightedBug;

    private void Start()
    {
        var bugsArray = FindObjectsOfType<BugManager>();
        foreach (var bug in bugsArray)
            bugs.Add(bug);
    }

    private void Update()
    {
        if (bugs.Count == 0) return;

        if (Input.GetMouseButtonDown(0))
            SelectOnMouseDown();
        else if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (selectedBugIdx >= bugs.Count)
            {
                SelectedBug = null;
                selectedBugIdx = 0;
            }
            else
                SelectedBug = bugs[selectedBugIdx++];
            //print(SelectedBug);
        }
        else if (Input.GetKeyDown(KeyCode.Escape))
        {
            Deselect();
        }
        //else if (Input.GetMouseButtonDown(1))
        //    SelectOnMouseDown(true);

        if (previewSelection) // TODO: Move
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.CompareTag("target"))
                {
                    highlightedBug = hit.collider.GetComponent<BugManager>();
                    if (highlightedBug != null)
                        highlightedBug.bmm.outline.enabled = true;
                }
                else
                {
                    if (highlightedBug != null)
                        highlightedBug.bmm.outline.enabled = false;
                }
            }
            else
            {
                if (highlightedBug != null)
                    highlightedBug.bmm.outline.enabled = false;
            }
        }
    }

    public void Deselect()
    {
        SelectedBug = null;
        selectedBugIdx = 0;
    }

    private void SelectOnMouseDown(bool isDestroy = false)
    {
        // http://answers.unity.com/answers/787227/view.html
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.CompareTag("target"))
            {
                SelectedBug = hit.collider.GetComponent<BugManager>();
                //selectedBugIdx = Array.IndexOf(bugs, SelectedBug) + 1;
                selectedBugIdx = bugs.FindIndex(bug => bug == SelectedBug) + 1;

                if (isDestroy && SelectedBug != null) // TEMP
                    SelectedBug.Kill();
            }
            //else
            //{
            //    SelectedBug = null;
            //    selectedBugIdx = 0;
            //}
        }
    }

    public void AddBug(BugManager bug)
    {
        bugs.Add(bug);
    }
}
