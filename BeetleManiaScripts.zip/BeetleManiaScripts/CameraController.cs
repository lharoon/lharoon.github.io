using UnityEngine;

public class CameraController : MonoBehaviour
{
    public float manualSpeed = 100f;
    public float autoSpeed = 10f;

    public bool isManual;

    private GameManager gm; // TODO: Rename

    private void Start()
    {
        gm = FindObjectOfType<GameManager>();
    }

    private void Update()
    {
        if (gm.ActiveCam != VCType.ArenaCam) return;

        float y = isManual ? Input.GetAxis("Horizontal") * manualSpeed : autoSpeed;

        transform.Rotate(transform.rotation.eulerAngles.x, y * Time.deltaTime,
            transform.rotation.eulerAngles.z);
    }
}
