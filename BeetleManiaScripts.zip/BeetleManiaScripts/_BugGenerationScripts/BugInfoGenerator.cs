using System.Collections.Generic;
using UnityEngine;

public class BugInfoGenerator : MonoBehaviour
{
    public List<Material> materials;

    public BugInfo GenerateBugInfo()
    {
        BugInfo bugInfo = new BugInfo();

        bugInfo.guid = System.Guid.NewGuid();
        bugInfo.bugName = BugNameGenerator.GetRandomName();
        bugInfo.university = BugNameGenerator.GetRandomUniversity();
        bugInfo.favouriteSandwich = BugNameGenerator.GetRandomSandwich();
        bugInfo.RandomiseAttributeValues();
        bugInfo.RandomiseAbilities();
        bugInfo.RandomiseBeetleType();
        bugInfo.materialIdx = Random.Range(0, materials.Count);
        bugInfo.material = materials[bugInfo.materialIdx];
        bugInfo.hatMaterialIdx = Random.Range(0, materials.Count);
        bugInfo.hatMaterial = materials[bugInfo.hatMaterialIdx];

        return bugInfo;
    }
}
