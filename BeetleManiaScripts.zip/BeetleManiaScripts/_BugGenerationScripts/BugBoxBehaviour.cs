using System.Collections;
using System.Collections.Generic;
using BeetleMania;
using DG.Tweening;
using UnityEngine;

public class BugBoxBehaviour : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public Transform bugPrefab;
    public GameObject boxExplosionPrefab, boxLandingPrefab;
    public float spawnTime;

    public Transform model;
    #endregion

    public BugInfo BugInfo { get; set; }
    public Transform SpawnPoint { get; set; }

    public List<Material> fadeMaterials;

    public SFXPlayer landingSfx, spawnSfx;

    private BugSelector bs;

    // Flags
    private bool isSpawning;

    private void Awake()
    {
        bs = FindObjectOfType<BugSelector>();
    }

    private void Start()
    {
        foreach (var meshRenderer in model.GetComponentsInChildren<SkinnedMeshRenderer>())
        {
            meshRenderer.material = BugInfo.material;
        }

        model.localScale = Vector3.zero;
        model.DOScale(0.25f, 0.5f);
    }

    private void OnCollisionEnter(Collision collision)
    {
        var landingFx = Instantiate(boxLandingPrefab, collision.GetContact(0).point, Quaternion.identity);
        Destroy(landingFx, 3f);

        if (!isSpawning)
        {
            isSpawning = true;
            StartCoroutine(OpenBox());
            StartCoroutine(SpawnAfterT(spawnTime));
        }

        landingSfx.PlaySFX();
    }

    private IEnumerator OpenBox()
    {
        float t = spawnTime - 1.15f;

        yield return new WaitForSeconds(t);

        if (transform.rotation.eulerAngles.x < -45f || transform.rotation.eulerAngles.x > 45f ||
            transform.rotation.eulerAngles.z < -45f || transform.rotation.eulerAngles.z > 45f)
        {
            yield return new WaitForSeconds(spawnTime - t);
            Destroy(gameObject);
        }

        model.GetComponent<Animator>().SetTrigger("open");

        yield return new WaitForSeconds(3);

        foreach (var meshRenderer in model.GetComponentsInChildren<SkinnedMeshRenderer>())
        {
            meshRenderer.material = fadeMaterials[BugInfo.materialIdx];
            meshRenderer.material.DOFade(0, 1.5f);
        }

        yield return new WaitForSeconds(1.5f);

        Destroy(gameObject);
    }

    private IEnumerator SpawnAfterT(float t)
    {
        yield return new WaitForSeconds(t);

        // Explosion fx
        var explosionFx = Instantiate(boxExplosionPrefab, transform.position, Quaternion.identity);
        Destroy(explosionFx, 3f);

        SpawnBug();

        //Destroy(gameObject);

        spawnSfx.PlaySFX();
        spawnSfx.transform.parent = explosionFx.transform; // Parent sfx to fx so that it plays
    }

    private void SpawnBug()
    {
        var bug = Instantiate(bugPrefab, SpawnPoint.parent);

        Vector3 bugPos = transform.position;
        bugPos.y = 0;
        bug.transform.position = bugPos;
        //bug.parent = tm.arenas[tm.ActiveArenaIdx].transform;

        var bm = bug.GetComponentInChildren<BugManager>();
        bm.bugInfo = BugInfo;
        bm.bmm.SetMaterial(BugInfo.material);
        bm.bmm.SetHatMaterial(BugInfo.hatMaterial); // TEMP
        bm.gameObject.layer = BugInfo.layer;

        var am = FindObjectOfType<ArenasManager>();
        bm.transform.parent.parent = am.arenas[am.ActiveArenaIdx].transform;

        bs.AddBug(bm);
    }
}
