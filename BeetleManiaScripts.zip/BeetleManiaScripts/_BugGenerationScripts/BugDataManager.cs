using UnityEngine;

public class BugDataManager : MonoBehaviour
{
    private const string allNamesKey = "allNames";

    #region Old
    public void GenerateBug()
    {
        BugInfo bug = new BugInfo();

        string bName = "";

        do
        {
            bName = BugNameGenerator.GetRandomName();

        } while (PlayerPrefs.HasKey(bName)); // TEMP

        bug.bugName = bName;

        foreach (var atr in bug.attributes) // Move to function
            atr.value = Random.Range(GameInfo.minAtrVal, GameInfo.maxAtrVal + 1);

        SaveToPP(bug);
    }

    public void ClearAllBugs()
    {
        PlayerPrefs.DeleteAll();
    }

    public void SaveToPP(BugInfo bug)
    {
        //PlayerPrefs.SetString(bug.bugName, bug.bugName); // Strange...
        string allNames = PlayerPrefs.GetString(allNamesKey) + " " + bug.bugName;
        PlayerPrefs.SetString(allNamesKey, allNames);

        foreach (var atr in bug.attributes)
            PlayerPrefs.SetFloat(GetKeyStr(bug.bugName, atr.guiName), atr.value);

        PlayerPrefs.SetInt(GetKeyStr(bug.bugName, "modelIdx"), bug.modelIdx);
        PlayerPrefs.SetInt(GetKeyStr(bug.bugName, "materialIdx"), bug.materialIdx);

        PlayerPrefs.SetString(GetKeyStr(bug.bugName, "notes"), bug.notes);
    }

    private string GetKeyStr(string bugName, string atrName)
    {
        return bugName + "_" + atrName;
    }

    public BugInfo LoadFromPP(string bugName)
    {
        //string[] bugs = PlayerPrefs.GetString(allNamesKey).Split(' ');
        if (!PlayerPrefs.GetString(allNamesKey).Contains(bugName))
            return null;

        BugInfo bug = new BugInfo();

        bug.bugName = bugName;

        foreach (var atr in bug.attributes)
            atr.value = PlayerPrefs.GetInt(GetKeyStr(bugName, atr.guiName));

        bug.modelIdx = PlayerPrefs.GetInt(GetKeyStr(bug.bugName, "modelIdx"));
        bug.materialIdx = PlayerPrefs.GetInt(GetKeyStr(bug.bugName, "materialIdx"));

        bug.notes = PlayerPrefs.GetString(GetKeyStr(bug.bugName, "notes"));

        return bug;
    }
    #endregion

    #region New
    public void SaveToPlayerPrefs(BugInfo bug)
    {
        PlayerPrefs.SetString(GetKeyStr(bug.guid.ToString(), "guid"), bug.guid.ToString());
        PlayerPrefs.SetString(GetKeyStr(bug.guid.ToString(), "bugName"), bug.bugName);
        foreach (var atr in bug.attributes)
            PlayerPrefs.SetFloat(GetKeyStr(bug.guid.ToString(), atr.guiName), atr.value);
        //PlayerPrefs.SetInt(GetKeyStr(bug.guid.ToString(), "modelIdx"), bug.modelIdx);
        PlayerPrefs.SetInt(GetKeyStr(bug.guid.ToString(), "materialIdx"), bug.materialIdx);
        PlayerPrefs.SetString(GetKeyStr(bug.guid.ToString(), "notes"), bug.notes);
    }

    public void LoadFromPlayerPrefs(System.Guid guid)
    {
        // TODO
    }
    #endregion
}
