using System.Collections.Generic;
using UnityEngine;

public class SpawnPointBehaviour : MonoBehaviour
{
    // TODO: Make private & use [SerializeField]
    #region Inspector fields 
    public BugBoxBehaviour bugBoxPrefab;
    public Transform bugPrefab;

    public List<Material> materials;
    public MeshRenderer model;

    public float dropHeight = 5f;

    public bool isRandom = true; // TEMP
    public BugInfo bugInfo = new BugInfo();

    public bool isBoxed = true;
    #endregion

    public BugManager AssociatedBug { get { return associatedBug; } }

    private BugSelector bs;

    private BugManager associatedBug;

    private bool hasFoundAssociatedBug;

    private void Awake()
    {
        bs = FindObjectOfType<BugSelector>();
    }

    private void Start()
    {
        if (isRandom)
        {
            // Set random material
            int materialIdx = Random.Range(0, materials.Count);
            model.material = materials[materialIdx];

            // Randomise bug info
            bugInfo.guid = System.Guid.NewGuid();
            bugInfo.bugName = BugNameGenerator.GetRandomName();
            bugInfo.university = BugNameGenerator.GetRandomUniversity();
            bugInfo.favouriteSandwich = BugNameGenerator.GetRandomSandwich();
            bugInfo.materialIdx = materialIdx;
            bugInfo.material = materials[materialIdx];
            bugInfo.hatMaterialIdx = Random.Range(0, materials.Count); // TEMP
            bugInfo.hatMaterial = materials[bugInfo.hatMaterialIdx];

            bugInfo.RandomiseAttributeValues();
            bugInfo.RandomiseAbilities();
            bugInfo.RandomiseBeetleType();
        }
        else
        {
            model.material = bugInfo.material;
        }

        bugInfo.layer = gameObject.layer;

        if (isBoxed)
            SpawnBugBox();
        else
            SpawnBug();

        model.gameObject.SetActive(false);
    }

    private void Update()
    {
        if (!hasFoundAssociatedBug && associatedBug == null)
        {
            GetAssociatedBug();
        }
        else if (associatedBug == null)
        {
            Destroy(gameObject);
        }
    }

    private void GetAssociatedBug()
    {
        var bugs = FindObjectsOfType<BugManager>();
        foreach (var bug in bugs)
        {
            if (bug.bugInfo.guid == bugInfo.guid)
            {
                associatedBug = bug;
                hasFoundAssociatedBug = true;
                break;
            }
        }
    }

    private void SpawnBugBox()
    {
        Vector3 spawnPos = transform.position;
        spawnPos.y = dropHeight;

        float rotLimit = 15f;
        var rotation = Quaternion.Euler(Random.Range(-rotLimit, rotLimit),
            Random.Range(-rotLimit, rotLimit),
            Random.Range(-rotLimit, rotLimit));
        //var rotation = Quaternion.Euler(0, Random.Range(0, 360f), 0);

        var bugBox = Instantiate(bugBoxPrefab, spawnPos, rotation);
        bugBox.transform.parent = transform.parent;
        bugBox.BugInfo = bugInfo;
        bugBox.SpawnPoint = transform;
    }

    private void SpawnBug()
    {
        var bug = Instantiate(bugPrefab);
        bug.transform.position = transform.position;
        bug.rotation = transform.rotation;

        var bm = bug.GetComponentInChildren<BugManager>();
        bm.bugInfo = bugInfo;
        bm.bmm.SetMaterial(bugInfo.material);
        bm.bmm.SetHatMaterial(bugInfo.hatMaterial);
        bm.enabled = false;
        //bm.IsInanimate = true; // TEMP

        bs.AddBug(bm);
    }
}
