using BeetleMania;
using UnityEngine;

public class SpawnPointPlacer : MonoBehaviour
{
    public Transform spawnPointPrefab;

    private bool isWithinBounds;

    private void Update()
    {
        Vector3 newPos = InputUtils.GetMousePosInWorld();
        newPos.y = transform.position.y;
        transform.position = newPos;

        if (Input.GetMouseButtonUp(0))
        {
            if (isWithinBounds)
                InstantiateSpawnPoint();
            Destroy(gameObject);
        }
    }

    private void InstantiateSpawnPoint()
    {
        Vector3 spawnPos = transform.position;
        var spawnPoint = Instantiate(spawnPointPrefab, spawnPos, Quaternion.identity);

        var am = FindObjectOfType<ArenasManager>();
        spawnPoint.parent = am.arenas[am.ActiveArenaIdx].transform;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("boundary"))
        {
            //mr.enabled = true;
            isWithinBounds = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("boundary"))
        {
            //mr.enabled = false;
            isWithinBounds = false;
        }
    }
}
