using UnityEngine;

public static class BugNameGenerator // TODO: Rename
{
    // https://www.fantasynamegenerators.com/insect-names.php
    static string concatenatedNames = "Scratch;Friskie;Poison;Echo;Ashes;Doodle;Spinner;Cuddles;Thunder;Sherlock;Thor;Salt;Cinder;Jaffa;Shadow;Boots;Chewy;Stitches;Venom;Lance;Chuck;Slinky;Whiskers;Bugs;Chuckles;Jitters;Dracula;Noodles;Junior;Ozzy;Icky;Comet;Psycho;Houdini;Casper;Xander;Aragog;Pickles;Sox;Buddy;Shade;Hunter;Snyder;Hector;Beta;Flopsie;Ash;Marble;Mittens;Frankenstein;Boomer;Tremor;Jiggles;Celeb;Blade;Lucifer;Peanut;Rascal;Biggelsworth;Whisper;Nightmare;Doc;Bilbo;Chewbacca;Spike;Asterix;Psyche;Wolfgang;Punky;Godzilla;Ghost;Trapper;Dexter;Muffin;Butch;Rufus;Ziggy;Xanadu;Skinner;Poppers;Blitz;Striker;Ivan;Omega;Brutus;Handsome;Rebel;Sylvester;Goliath;Taboo;Prometheus;Phantom;Magma;Scruff;Gadget;Darcy;Scruffy;Rusty;Apollo";
    static string[] names;

    // https://www.topuniversities.com/student-info/choosing-university/worlds-top-100-universities
    static string concatenatedUniversities = "Massachusetts Institute of Technology (MIT);University of Oxford;Stanford University;University of Cambridge;Harvard University;California Institute of Technology (Caltech);Imperial College London;ETH Zurich (Swiss Federal Institute of Technology);UCL (University College London);University of Chicago;National University of Singapore (NUS);Nanyang Technological University, Singapore (NTU);University of Pennsylvania;Ecole Polytechnique Fédérale de Lausanne (EPFL);Yale University;University of Edinburgh;Tsinghua University;Peking University;Columbia University;Princeton University;Cornell University;University of Hong Kong (UKU);University of Tokyo;University of Michigan-Ann Arbor;Johns Hopkins University;University of Toronto;McGill University;Australian National University;University of Manchester;Northwestern University;Fudan University;University of California, Berkeley (UCB);Kyoto University;Hong Kong University of Science and Technology (HKUST);King's College London;Seoul National University;University of Melbourne;University of Sydney;Chinese University of Hong Kong (CUHK);University of California, Los Angeles (UCLA);KAIST - Korea Advanced Institute of Science & Technology;New York University (NYU);University of New South Wales (UNSW Sydney);Universite PSL;Zhejiang University;University of British Columbia;University of Queensland;University of California, San Diego (UCSD);London School of Economics and Political Science (LSE);Shanghai Jiao Tong University;Technical University of Munich;Duke University;Carnegie Mellon University;City University of Hong Kong;University of Amsterdam;Tokyo Institute of Technology;Delft University of Technology;Monash University;Institut Polytechnique de Paris;Brown University;University of Warwick;University of Bristol;Ruprecht-Karls-Universitat Heidelberg;Ludwig-Maximilians-Universität München;Universiti Malaya (UM);Hong Kong Polytechnic University;University of Texas at Austin;National Taiwan University (NTU);Universidad de Buenos Aires (UBA);KU Leuven;University of Zurich;Sorbonne University;University of Glasgow;Korea University;Osaka University;University of Wisconsin-Madison;University of Southampton;Lomonosov Moscow State University;University of Copenhagen;Yonsei University;Pohang University of Science and Technology (POSTECH);Durham University;Tohoku University;University of Illinois at Urbana-Champaign;University of Auckland;University of Washington;Lund University;Georgia Institute of Technology;KTH Royal Institute of Technology;University of Birmingham;University of St Andrews;University of Leeds;University of Western Australia;Rice University;University of Sheffield;University of Pennsylvania;Sungkyunkwan University (SKKU);University of Science and Technology of China;Technical University of Denmark;University of North Carolina, Chapel Hill";
    static string[] universities;

    // https://en.wikipedia.org/wiki/List_of_sandwiches
    static string concatenatedSandwiches = "American sub;Bacon;Bacon, egg and cheese;Bagel toast;Baked bean;Bologna salad sandwich;Bánh mì;Barbecue;Barros Jarpa;Barros Luco;Bauru;Beef on weck;Beirute;BLT;Bocadillo;Bologna;Bosna;Bratwurst;Breakfast roll;Breakfast;British Rail;Butifarra [es];Broodje kroket;Bun kebab;Butterbrot;Carrozza;Caviar;Cemita;Chacarero;Cheese;Cheese dream;Cheese and pickle;Cheesesteak;Chicken;Chicken salad;Chicken schnitzel;Chickpea salad;Chili burger;Chimichurris;Chip butty;Chipped beef;Chivito;Chocolate;Chopped cheese;Choripán;Chow mein sandwich;Churrasco;Club;Corned beef;Crisp;Croque-monsieur;Croque-madame;Cuban;Cucumber;Cudighi;Grilled cottage cheese sandwich;Cutlet sandwich, Italian;Dagwood;Deli;Denver;Doner kebab;Donkey burger;Doubles;Doughnut sandwich;Dynamite;Dyrlægens natmad;Elvis;Egg;Falafel;Farroupilha;Fischbrötchen;Fish finger;Fluffernutter;Fool's Gold Loaf;Francesinha;Francesinha poveira;French dip;Fried brain;Fruit;Ftira;Gatsby;Gerber;Gua bao;Guajolota;Guédille;Grillade;Gyro;Hagelslag or vlokken;Ham;Ham and pickle sandwich;Ham and cheese;Ham and egg bun;Hamburger;Hamglizzy;Har cheong gai burger;Horseshoe;Hot brown;Hot dog;Hot chicken;Hot turkey;Ice cream;Indian taco;Italian beef;Italian;Jam;Jambon-beurre;Jibarito;Jucy Lucy;Kanapka;Katsu sando(ja);Kabuli burger;Kaisers Jagdproviant;Khao Jee Pâté;Kokoretsi;Kottenbutter;Leberkäse;Lettuce sandwich;Limburger;Lobster roll;Lox;Luther burger;Mallorca de jamón y queso;Marmalade;Marmite;Martino;Meatball;Medianoche;Melt;Mettbrötchen;Mezcla;Mitraillette;Mollete;Montadito;Monte Cristo;Montreal-style smoked meat;Mortadella;Mother-in-law;Muffuletta;Naan;Obložené chlebíčky;Open-faced;Pambazo;Pan-bagnat;Panini;Pastrami on rye;Patty melt;Peameal bacon sandwich;Peanut butter and jelly;Pebete;Pepito;Pepper and egg;Pepper and egg, Italian;Pilgrim;Pimento cheese;Pistolette;Pljeskavica;Po' boy;Polish boy;Porchetta;Porilainen;Pork chop bun;Pork roll sandwich;Pork tenderloin;Prawn roll;Prego;Primanti;Prosperity Sandwich;Pudgy pie;Pulled pork;Queen Alexandra's sandwich;Rachel;Reuben;Roast beef;Roti bakar;Roti john;Rou jia mo;Ruisleipä;Runza;Sabich;Sailor;Sándwich de milanesa;Sandwich loaf;Sandwiches de miga;Salt beef bagel;Sausage;Sausage, pepper, and onion sub/hoagie;Schmitter;Sealed crustless;Shawarma;Shooter's sandwich;Shuco;Slider;Sloppy joe;Sloppy joe (New Jersey);Smörgåstårta;Smørrebrød;Sol over Gudhjem;Souvlaki;Spaghetti;Specials, Deli sandwiches;Spiedie;St. Paul;Steak bomb;Steak burger;Steak;Submarine/Sub/Baguette;Tavern;Tea;Toast;Toast Hawaii;Toastie;Tofu;Tongue toast;Torta;Torta ahogada;Tramezzino;Trancapecho;Tripleta;Tuna;Turkey Devonshire;Turkey;Vada pav;Vegemite;Vegetable;Veggie burger;Wrap;Wurstbrot (sausage bread);Yakisoba-pan;Zapiekanka;Zsíroskenyér;Spatlo";
    static string[] sandwiches;

    static BugNameGenerator()
    {
        //names = concatenatedNames.Split(' ');
        names = concatenatedNames.Split(';');
        universities = concatenatedUniversities.Split(';');
        sandwiches = concatenatedSandwiches.Split(';');
    }

    public static string GetRandomName()
    {
        return names[Random.Range(0, names.Length)];
    }

    public static string GetRandomUniversity()
    {
        return universities[Random.Range(0, names.Length)];
    }

    public static string GetRandomSandwich()
    {
        return sandwiches[Random.Range(0, names.Length)];
    }
}
