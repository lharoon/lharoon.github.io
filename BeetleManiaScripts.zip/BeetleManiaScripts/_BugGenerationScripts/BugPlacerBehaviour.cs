using UnityEngine;

public class BugPlacerBehaviour : MonoBehaviour
{
    public Transform bugPrefab;

    private Vector3 worldPosition;
    private bool isWithinBounds;

    private BugSelector bs;
    private TestManager tm;

    private void Start()
    {
        bs = FindObjectOfType<BugSelector>();
        tm = FindObjectOfType<TestManager>();
    }

    private void Update()
    {
        Vector3 newPos = GetMousePosInWorld();
        newPos.y = transform.position.y;
        transform.position = newPos;

        if (Input.GetMouseButtonUp(0))
        {
            if (isWithinBounds)
                SpawnBug();
            Destroy(gameObject);
        }
    }

    private void SpawnBug()
    {
        var bug = Instantiate(bugPrefab);

        Vector3 bugPos = transform.position;
        bugPos.y = 0;
        bug.transform.position = bugPos;

        var bm = bug.GetComponentInChildren<BugManager>();
        bm.RandomiseAttributeValues();
        bm.bugInfo.bugName = BugNameGenerator.GetRandomName();
        bm.bmm.SetRandom();

        bs.AddBug(bm);

        bug.parent = tm.arenas[tm.ActiveArenaIdx].transform;
    }

    private Vector3 GetMousePosInWorld() // TODO: Move to separate class
    {
        Plane plane = new Plane(Vector3.up, 0);

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (plane.Raycast(ray, out float distance))
        {
            worldPosition = ray.GetPoint(distance);
        }

        return worldPosition;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("boundary"))
        {
            isWithinBounds = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("boundary"))
        {
            isWithinBounds = false;
        }
    }
}
