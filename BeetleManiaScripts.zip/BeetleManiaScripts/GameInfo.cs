using System;
using System.Collections.Generic;
using UnityEngine;

public static class GameInfo
{
    public static bool isDebug = true;

    public static int minAtrVal = 0, maxAtrVal = 3;
    public static float minArenaExt = -4f, maxArenaExt = 4f;
    public static Color red = new Color(255, 54, 62);
    public static Color black = new Color(34, 35, 35);

    // TEMP
    public static List<BugInfo> bugs = new List<BugInfo>();
    public static BugInfo contestant1, contestant2;
    public static RoundNum currentRound;
    public static List<BugInfo> roundWinners = new List<BugInfo>();
    public static List<BugInfo> roundLosers = new List<BugInfo>(); // TEMP
    public static int bugIdx = 0, winnerIdx = 0;

    public static bool isMatchUnderway;

    // Scene names
    public static string titleScreenName = "0_TitleScreen";
    public static string pictorialIntroName = "1_PictorialIntro";
    public static string textIntroName = "2_TextIntro";
    public static string mainMenuName = "3_MainMenu";
    public static string tournamentSelectionScreenName = "4_TournamentSelectionScreen";
    public static string tournamentScreenName = "5_TournamentScreen";
    public static string bettingScreenName = "6_BettingScreen";
    public static string matchName = "7_Match";

    public static string playgroundName = "Playground";

    // Input
    public static KeyCode advanceKey = KeyCode.Return;

    // TEMP
    public static string previousScene = "";
    public static int lastActiveArenaIdx = 0;

    // Colours change every game
    public static Dictionary<AbilityType, GemColour> abilityColours = new Dictionary<AbilityType, GemColour>();

    // Betting variables
    public static int credit = 100;
    public static BugInfo bugBeingBetOn;
    public static int betValue, winnings;

    // Tournament wide betting variables
    public static BugInfo bugForSemis, bugForFinals, bugForChampion;
    //public static int betSemis, betFinals, betChampion;
    public static int winningsSemis, winningsFinals, winningsChampion;

    public static bool skipRound;

    public static bool playSfx, playBgm;

    static GameInfo()
    {
        var abilityTypes = Enum.GetValues(typeof(AbilityType));
        var gemColours = Enum.GetValues(typeof(GemColour));

        for (int i = 0; i < Enum.GetNames(typeof(AbilityType)).Length; i++)
        {
            int clrIdx = UnityEngine.Random.Range(0, gemColours.Length);
            abilityColours.Add((AbilityType)abilityTypes.GetValue(i),
                (GemColour)gemColours.GetValue(clrIdx));

            //Debug.Log((AbilityType)abilityTypes.GetValue(i) + ": " +
            //    abilityColours[(AbilityType)abilityTypes.GetValue(i)]);
        }
    }
}
