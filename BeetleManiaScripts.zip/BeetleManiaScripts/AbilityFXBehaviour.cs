using UnityEngine;

public class AbilityFXBehaviour : MonoBehaviour
{
    public ParticleSystem ps1, ps2;

    public void SetColour(Color colour)
    {
        var main1 = ps1.main;
        main1.startColor = colour;

        var main2 = ps2.main;
        main2.startColor = colour;
    }
}
